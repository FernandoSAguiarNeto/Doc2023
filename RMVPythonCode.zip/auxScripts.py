import numpy as np
import mne
import networkx as nx

#########
### SIGNAL (SENOID) AND NOISE PRODUCTION AND MANIPULATION
#########

def digitizeSignal(signal, bins = np.arange(-3,3,0.05)):
    bin_data = np.digitize(signal, bins=bins)
    signalDigitized = [bins[bin_data[n]-1] for n in range(len(signal.reshape(-1)))]
    return signalDigitized

def makeSignal(sines, start=0, end=10, sample_rate=100, theta=0, amplitude=1):
    import numpy as np
    import matplotlib.pyplot as plt
    sample_rate = sample_rate
    time = np.arange(start, end, 1 / sample_rate)
    signal = np.sin(2 * np.pi * sines[0] * time + theta)
    for x in range(1, len(sines)):
        signal = signal + np.sin(2 * np.pi * sines[x] * time + theta)
    signal = amplitude * signal
    return signal

def makeNoise(noise_strength=1, num_samples=None, start=0, end=10, sample_rate=100):
    if num_samples is None:
        time = np.arange(start, end, 1 / sample_rate)
    else:
        time = np.zeros(num_samples)
    noise = np.random.rand(len(time), ) * noise_strength
    return noise

##############
## TDA

# returns a sparse distance matrix for alpha filtration
# Same code as providede by ripser itself (https://ripser.scikit-tda.org/en/latest/notebooks/Lower%20Star%20Time%20Series.html)
# signal is a series of data, presumably a time-series
def lowerStarPrep(signal):
    import numpy as np
    from scipy import sparse

    N = len(signal)
    # Add edges between adjacent points in the time series, with the "distance"
    # along the edge equal to the max value of the points it connects
    I = np.arange(N - 1)
    J = np.arange(1, N)
    V = np.maximum(signal[0:-1], signal[1::])
    # Add vertex birth times along the diagonal of the distance matrix
    I = np.concatenate((I, np.arange(N)))
    J = np.concatenate((J, np.arange(N)))
    V = np.concatenate((V, signal))
    # Create the sparse distance matrix
    D = sparse.coo_matrix((V, (I, J)), shape=(N, N)).tocsr()
    return D
    # Usage example:
    # dgm0 = ripser(D, maxdim=0, distance_matrix=True)['dgms'][0]


#max_dim (int, default:1)-> indicates the maximum dimension of hole persistence to be plot;
#subplot (None|int, default=220) -> if None, will plot all dimensions in a single plot;
### if an integer it must be a 3 digit number: rc0, where r are the number or rows, and c the number of columns, e.g. 320 for a 3 row with 2 columns subplot.
def plotHomology(adjm, max_dim=1, subplot=220):
    from ripser import ripser
    from persim import plot_diagrams
    import matplotlib.pyplot as plt

    dgms = ripser(adjm, distance_matrix=True)['dgms']
    if subplot is None:
        for i in range(max_dim + 1):
            plot_diagrams(dgms, plot_only=[i])
    else:
        for i in range(max_dim+1):
            plot_diagrams(dgms, plot_only=[i],ax=plt.subplot(subplot+(i+1)))

########
## GRAPHICS AND PLOTS
def plotSignal(sig):
    import matplotlib.pyplot as plt
    plt.figure(figsize=(20, 6), dpi=80)
    plt.plot(sig)

def plotTakens(tk):
    import matplotlib.pyplot as plt
    plt.scatter(tk['0'], tk['1'], c=np.arange(0, len(tk)))

def plotTakens3d(tk):
    import matplotlib.pyplot as plt
    import pandas as pd
    import seaborn as sns
    from mpl_toolkits.mplot3d import Axes3D

    sns.set(style="darkgrid")

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    ax.scatter(tk['0'], tk['1'], tk['2'])

    plt.show()

# plotTakensPCA code strongly based on https://plotly.com/python/pca-visualization/
def plotTakensPCA(tk, d=3):
    import plotly.express as px
    from sklearn.decomposition import PCA

    pca = PCA(n_components=d)
    components = pca.fit_transform(tk)

    total_var = pca.explained_variance_ratio_.sum() * 100

    if d == 3:
        fig = px.scatter_3d(
            components, x=0, y=1, z=2,
            title=f'Total Explained Variance: {total_var:.2f}%',
            labels={'0': 'PC 1', '1': 'PC 2', '2': 'PC 3'})
        fig.show()
    elif d == 2:
        fig = px.scatter(components, x=0, y=1, title=f'Total Explained Variance: {total_var:.2f}%',
                         labels={'0': 'PC 1', '1': 'PC 2'})
        fig.show()
    elif d == 1:
        fig = px.scatter(components, x=0, y=0, title=f'Total Explained Variance: {total_var:.2f}%',
                         labels={'0': 'PC 1'})
        fig.show()
    else:
        labels = {str(i): f"PC {i + 1} ({var:.1f}%)" for i, var in enumerate(pca.explained_variance_ratio_ * 100)}

        fig = px.scatter_matrix(
            components,
            labels=labels,
            dimensions=range(d),
        )
        fig.update_traces(diagonal_visible=False)
        fig.show()


def plot_topomapData(data, channelSetup, upper=True, vmin=0, vmax=1, montageStr='standard_1005',
                     mask_params=dict(marker='o', markerfacecolor='w', markeredgecolor='k', linewidth=0, markersize=9),
                     ax=None):
    import mne
    import matplotlib.pyplot as plt
    # Plotting Features
    # Code addapted from here: https://mne.tools/dev/auto_examples/visualization/plot_eeglab_head_sphere.html#sphx-glr-auto-examples-visualization-plot-eeglab-head-sphere-py
    # Setting montage
    montage = mne.channels.make_standard_montage(montageStr)
    n_channels = len(montage.ch_names)
    if upper:
        for ch in range(0, len(montage.ch_names)):
            montage.ch_names[ch] = montage.ch_names[ch].upper()

    fake_info = mne.create_info(ch_names=channelSetup, sfreq=250.,
                                ch_types='eeg').set_montage(montage)  ## it is used only to hold the data we will input

    mask = np.full(len(channelSetup),
                   True)  # we apply a mask on all channels, it helps configure the image for readability

    if ax is None:
        fig, ax = plt.subplots(ncols=1, figsize=(6, 3), sharex=True, sharey=True, gridspec_kw={'wspace': 0.2})
        fig.set_tight_layout(True)
    im, _ = mne.viz.plot_topomap(data, fake_info, names=channelSetup, cmap='RdBu_r', vlim=(vmin, vmax), mask=mask,
                                 mask_params=mask_params, axes=ax, show=False)
    plt.colorbar(im, ax=ax)

######
## SPACE EMBEDDING
def takensEmbedding(sig, tau, d, step=1):
    import numpy as np
    import pandas as pd

    sig = np.array(sig)
    idx = np.array([tau * i for i in range(d)])

    if idx[-1] >= len(sig):
        print('signal too short')
        return pd.DataFrame([])

    tk = [sig[idx]]
    idx = idx + step
    while (idx[-1] < len(sig)):
        tk = np.concatenate((tk, [sig[idx]]), axis=0)
        idx = idx + step

    tk = pd.DataFrame(tk, columns=[str(i) for i in range(d)])
    return tk


# transitions = takensEmbedding(signalDigitized, tau=1, d=2) (e.g.)
# returns an adjacency matrix, with no self-loops; the distance (weights) are the inverse of the probability of transition between two nodes
#  (distance is np.inf for 0% trasitions)
def transitionsAdjm(transitions, draw=False):
    import networkx as nx
    graph = nx.MultiGraph()

    for _, t in transitions.iterrows():
        graph.add_edge(t['0'], t['1'])

    # graph.remove_edges_from(nx.selfloop_edges(graph))
    if draw:
        copy = graph.copy()
        copy.remove_edges_from(nx.selfloop_edges(copy))
        nx.draw(copy)

    adjm = nx.to_pandas_adjacency(graph)
    adjm = adjm.div(adjm.sum(axis=1), axis=0)
    adjm = 1 / adjm
    adjm = adjm.to_numpy(copy=False)
    np.fill_diagonal(adjm, 0)  # removes self.edges
    return adjm


##############
## GRAPH
## Most copied from https://github.com/guilhermesantos/redes_complexas
###############

def avg_deg(g):
    avg = 0
    for node, deg in g.degree():
        avg += deg
    avg = avg/len(list(g.degree()))
    return avg

def avg_cc(g):
    ccs, _, _ = cc_distribution(g)
    return np.sum(ccs)/len(ccs)

def avg_shortest_path_len(g):
    dists = dist_matrix(g).flatten()
    return np.sum(dists)/len(dists)

def cc_distribution(g):
    ccs = []
    for node in g.nodes():
        ccs.append(nx.clustering(g, node))
    ccs = np.array(ccs)
    #print('clustering de cada nó', local)
    unique, freq = np.unique(ccs, return_counts=True)
    dist = freq/sum(freq)
    return ccs, freq, dist

def compute_degrees(g):
    g_mat = nx.to_numpy_array(g, nodelist=sorted(g.nodes()))
    degs = np.sum(g_mat, 1, dtype=np.int64)
    return degs

def compute_metrics(g):
    node_qtt = len(g.nodes())
    avg_degree = avg_deg(g)
    moment = compute_moment(g, 2)
    avg_ccoef = avg_cc(g)
    transitivity = nx.transitivity(g)
    avg_path = avg_shortest_path_len(g)
    diameter = nx.diameter(g)
    return node_qtt, avg_degree, moment, avg_ccoef, transitivity, avg_path, diameter

def compute_moment(g, m):
    deg, _, dist = degree_distribution(g)
    moment = np.sum((deg**m)*dist)
    return moment

def complexity(g):
    degrees, freq, dist = degree_distribution(g)
    k_2 = 0
    k = 0
    for degree, frac in zip(degrees, dist):
        k_2 += (degree**2)*frac
        k += degree*frac
    return k_2/k


def degree_distribution(g):
    # Builds a list that contains only the degree of each node in the network
    degrees = np.array(list(dict(g.degree()).values()))

    # Counts how often each degree value appears on the list
    unique, counts = np.unique(degrees, return_counts=True)

    # Creates a list containing only zeroes
    # The index represents the degree, and the value it contains
    # represents how often that degree appears in the network
    # This step is necessary in order to set "0" to the frequency of
    # the degree values that are not present in the network
    freq = np.zeros(np.max(unique) + 1)

    possib = np.arange(np.max(unique + 1))
    # Populates the list with the frequency of the degree
    # values actually present in the network
    for value, count in zip(unique, counts):
        freq[value] = count

    # Divides the degree frequency array by the total number of nodes
    # in the network, thus resulting in the probability distribution
    # of a node in the network having a certain degree K
    # Or P(node_degree=k)
    dist = freq / len(g.nodes())
    return possib, freq, dist

def dist_matrix(g):
    nodes = list(g.nodes())
    nodes.sort()
    node_num = len(nodes)

    dist_mat = np.zeros((node_num, node_num))
    for i in np.arange(node_num):
        for j in np.arange(i + 1, node_num):
            # print('i=', i, 'nodes[i]=', nodes[i], 'j=', j, 'nodes[j]=', nodes[j])
            if (i != j):
                dist = len(nx.shortest_path(g, nodes[i], nodes[j])) - 1
                dist_mat[i][j] = dist
                dist_mat[j][i] = dist
    return dist_mat

##############
## EEG
###############

## EEG Reading and manipulation
# this will read the eeg a subject, and apply some preprocessing
# returns valid mne.Epochs
def readEpochs(db, subject, task, srate=250, correction='zscore', minFreq=4, maxFreq=30, refCh='average',
               cleanByEOG=True, cleanByEOGICA=False):
    import experiment
    gxp = experiment.Experiment()
    eeg = gxp.preprocess(db, subject, minFreq, maxFreq, refCh, cleanByEOG, cleanByEOGICA)
    epochs = db.extractEpochs(eeg, task, tminDelay=0.0, tmaxDelay=0.0, baseline=None, srate=srate,
                              correction=correction)
    return epochs


def readEEG(db, subject, minFreq=None, maxFreq=None, refCh='average', cleanByEOG=True,
            cleanByEOGICA=False, notch=True):
    import experiment
    gxp = experiment.Experiment()

    eeg = gxp.preprocess(db, subject, minFreq, maxFreq, refCh, cleanByEOG, cleanByEOGICA, notch)
    return eeg


def signalFromEpochs(epochs, ch):
    signals = np.array([epochs.get_data(picks=[ch])[e].reshape(-1) for e in range(0, len(epochs))])
    return signals

def keepOnlyAnnotations(annotation, descr):
    if type(descr)!= list:
        idx = []
        for i in range(len(annotation.description)):
            if annotation.description[i] != descr:
                idx.append(i)
        annotation.delete(idx)
    else:
        idx = []
        for i in range(len(annotation.description)):
            if not (annotation.description[i] in descr):
                idx.append(i)
        annotation.delete(idx)
    return annotation

#takes a dataFrame 'data', a task and a band {Alpha,Beta,Theta,Gamma,Delta} and extracts a DataFrame with Subjects as indexes and channels as columns
#usefull to format the files saved for bandPower experiments.
def bandPowerExtractor(data, band, task):
    import pandas as pd
    import itertools

    Bands = data.copy()
    Bands = Bands.drop('Unnamed: 0', axis=1)
    Bands = Bands[Bands.Band == band]
    Bands = Bands.drop('Band', axis=1)
    Bands = Bands[Bands.Task == task]
    Bands = Bands.drop('Task', axis=1)

    chs = list(set(Bands.Channel))
    subs = list(set(Bands.Subject))
    d = dict()
    pairs = list(itertools.product(subs, chs))
    for sub, ch in pairs:
        pow = Bands[(Bands.Subject == sub) & (Bands.Channel == ch)]
        d[sub] = d.get(sub, dict())
        d[sub][ch] = float(pow.Power)

    return pd.DataFrame.from_dict(d, orient='index')

## This function aims to make easy the use of machine learning algorihtms, as it will be easy to filter just the desired features and display them as vectors (which is standard input)
## Takes a dictionary with many features as returned by the Experiment package, notice that the the experiment ID must be already chosen:
   ##e.g.
   ## paramsFull = experiment.ExperimentParameters(ID="HOSS2013", ...)
   ## featuresDR = gxp.genericExperiment(dr,["EC2000ms"],[paramsFull]) #Only eyes closed
   ## flat_features = agregateAllFeatures(featuresDR['HOSS2013'])

# Tasks present, must be passed as parameter as a list, e.g. tasks=['EO','EC']

## return a single pandas DataFrame (indexed by subjectID) with all features, with a column for each feature, band powers are described as Power_<ch>_<band> all uppercase
def aggregateAllFeatures(featureDict, tasks):
    import pandas as pd
    import numpy as np

    flatFeatures = dict() ##Each task will be a key pointing to a DataFrame

    for task in tasks:

        flatFeatures[task] = pd.DataFrame()

        # Flatting channel-Band dependent features
        for feature in ['bandPowers','relativeBandPowers']:
            errorFound = False
            if list(featureDict.keys()).__contains__(feature):
                df = featureDict[feature] #just for coding simplicity
                subjects = pd.unique(df['Subject'])
                channels = pd.unique(df['Channel'].dropna(inplace=False))
                bands = pd.unique(df['Band'].dropna(inplace=False))

                featureData = pd.DataFrame(index=subjects)

                for ch in channels:
                    for band in bands:
                        col_name = feature + '_' + str(ch).upper() + '_' + str(band).upper()
                        values = df[(df['Band'] == band) & (df['Channel'] == ch) & (df['Task'] == task)]\
                            [['Subject', 'Power']].set_index('Subject')
                        values.columns = [col_name] # renaming column to feature_CH_BAND

                        featureData = pd.concat([featureData, values], axis=1, sort=True) ## Concatenating band powers for all subjects on this channel (one column)

                        ##cheking errors
                        if 'Error' in df.columns:
                            errors = df[(df['Band'] == band) & (df['Channel'] == ch) & (df['Task'] == task)]\
                                [['Subject', 'Error']].set_index('Subject')
                            errors = errors.dropna()
                            if len(errors) > 0:  # if there are errors, report, erros can be easily found once the feature is selected
                                errorFound = True

                if errorFound:
                    print('Errors found for feature: ', feature)
                flatFeatures[task] = pd.concat([flatFeatures[task], featureData], axis=1, sort=True) ## commiting data to flatFeatures

        # Flatting channel-only dependent features (feature_CH)
        for feature in ['CD', 'DFA', 'HFD']:
            errorFound = False
            if list(featureDict.keys()).__contains__(feature):
                df = featureDict[feature]  # just for coding simplicity
                subjects = pd.unique(df['Subject'])
                channels = pd.unique(df['Channel'].dropna(inplace=False))

                featureData = pd.DataFrame(index=subjects)

                for ch in channels:
                        col_name = feature + '_' + str(ch).upper()
                        value = df[(df['Channel'] == ch) & (df['Task'] == task)]\
                            [['Subject', feature]].set_index('Subject')
                        value.columns = [col_name] # renaming column to feature_CH

                        featureData = pd.concat([featureData, value], axis=1, sort=True) ## Concatenating band powers for all subjects on this channel (one column)

                        ##cheking errors
                        if 'Error' in df.columns:
                            errors = df[(df['Channel'] == ch) & (df['Task'] == task)] \
                                [['Subject', 'Error']].set_index('Subject')
                            errors = errors.dropna()
                            if len(errors) > 0:  # if there are errors, report, erros can be easily found once the feature is selected
                                errorFound = True

                if errorFound:
                    print('Errors found for feature: ', feature)
                flatFeatures[task] = pd.concat([flatFeatures[task], featureData], axis=1, sort=True) ## commiting data to flatFeatures



        # Appending Independent features
        for feature in ['SASI']:
            errorFound = False
            if list(featureDict.keys()).__contains__(feature):
                df = featureDict[feature]
                subjects = pd.unique(df['Subject'])

                featureData = pd.DataFrame(index=subjects)

                col_name = feature
                value = df[(df['Task'] == task)] \
                    [['Subject', feature]].set_index('Subject')
                value.columns = [col_name]  # renaming column to feature_CH

                featureData = pd.concat([featureData, value],
                                        axis=1, sort=True)  ## Concatenating band powers for all subjects on this channel (one column)

                ##cheking errors
                if 'Error' in df.columns:
                    errors = df[(df['Channel'] == ch) & (df['Task'] == task)] \
                        [['Subject', 'Error']].set_index('Subject')
                    errors = errors.dropna()
                    if len(
                            errors) > 0:  # if there are errors, report, erros can be easily found once the feature is selected
                        errorFound = True

                if errorFound:
                   print('Errors found for feature: ', feature)

                flatFeatures[task] = pd.concat([flatFeatures[task], featureData],
                                               axis=1, sort=True)  ## commiting data to flatFeatures

        for feature, fname in [('alphaAsymmetry','AlphaAsymmetry'),('PCT','AlphaAsymmetry (PCT)')]:
            errorFound = False
            if list(featureDict.keys()).__contains__(feature):
                df = featureDict[feature]  # just for coding simplicity
                subjects = pd.unique(df['Subject'])
                channels = pd.unique(df['Channels'].dropna(inplace=False))

                featureData = pd.DataFrame(index=subjects)

                for ch in channels:

                    col_name = feature + '_' + str(ch).upper()
                    values = df[(df['Channels'] == ch) & (df['Task'] == task)] \
                        [['Subject', fname]].set_index('Subject')
                    values.columns = [col_name]  # renaming column to feature_CH_BAND

                    featureData = pd.concat([featureData, values], axis=1,
                                            sort=True)  ## Concatenating band powers for all subjects on this channel (one column)

                    ##cheking errors
                    if 'Error' in df.columns:
                        errors = df[(df['Channels'] == ch) & (df['Task'] == task)] \
                            [['Subject', 'Error']].set_index('Subject')
                        errors = errors.dropna()
                        if len(
                                errors) > 0:  # if there are errors, report, erros can be easily found once the feature is selected
                            errorFound = True

                if errorFound:
                    print('Errors found for feature: ', feature)
                flatFeatures[task] = pd.concat([flatFeatures[task], featureData], axis=1,
                                               sort=True)  ## commiting data to flatFeatures

    return flatFeatures

# Returns the indexes that have values closer to min and max.
# in such way that freqs[lowIdx] >= min and freqs[lowIdx] < max, maintaing the open ranges for the bands, e.g. [a,b)
# Source based on: https://stackoverflow.com/questions/2566412/find-nearest-value-in-numpy-array
# Thanks to: unutbu (https://stackoverflow.com/users/190597/unutbu)
def extractFreqOfInterestIndexes(freqs, min, max):
    import numpy as np
    lowIdx = (np.abs(freqs - min)).argmin()
    if freqs[lowIdx] < min:
        lowIdx = lowIdx +1 #freqs is a sorted array
    highIdx = (np.abs(freqs - max)).argmin()
    if freqs[highIdx] >= max:
        highIdx = highIdx - 1  # freqs is a sorted array

    return lowIdx, highIdx


# returns a dict that maps the content of a list to its ID.
# e.g. list = [a,b,c] ====> return d = {a:0, b:1, c:2}
def invertList(list):
    d = dict()
    for i in range(0, len(list)):
        d[list[i]] = i

    return d


# source: https://stackoverflow.com/questions/4719438/editing-specific-line-in-text-file-in-python
# Thanks to: Peter C (https://stackoverflow.com/users/470535/peter-c)
def replace_line(file_name, line_num, text):
    lines = open(file_name, 'r').readlines()
    lines[line_num] = text
    out = open(file_name, 'w')
    out.writelines(lines)
    out.close()


# Corrects the *.vhdr and *.vmrk headers so they point to the correct files.
# Works for the raw version, for the preprocessed will be needed another workaround.
# also puts all subjects in the same folder
def MindBodyRAWCorrection(path='D:\\WorkspaceDoc\\Databases\\MindBrainBody',
                          destinyPath='D:\\WorkspaceDoc\\Databases\\MindBrainBody\\AllSubjects\\'):
    # Getting path directories
    import os
    folders = []
    # r=root, d=directories, f = files
    for r, d, f in os.walk(path):
        if not r == path:
            break
        for folder in d:
            folders.append(path + "\\" + folder)

    os.mkdir(destinyPath)

    ##Changing Headers
    # Visiting each folder
    for f in folders:
        # getting subjectID
        subID = f.split("\\")[-1]

        ##Changing .vrmk
        replace_line(f + "\\RSEEG\\" + subID + ".vmrk", 4, "DataFile=" + subID + ".eeg\n")

        ##Changing .vhdr
        replace_line(f + "\\RSEEG\\" + subID + ".vhdr", 5, "DataFile=" + subID + ".eeg\n")
        replace_line(f + "\\RSEEG\\" + subID + ".vhdr", 6, "MarkerFile=" + subID + ".vmrk\n")

        ##.eeg file remais unchanged.
        ##Moving files to root
        os.system("copy " + f + "\\RSEEG\\* " + destinyPath)


# Transforms annotations in events
# Considers that annotation.orig_time and raw.first_samp are in sync, i.e. mean the same reading/time.
# Parameters:
##raw -> mne.io.raw, e.g. RawEEGLAB
##eventID -> dictionary that maps a string to an integer. Used to map the annotation description (string) to eventId (int)
### if no ID is found for a given description then the value will be automatically cast from str to int.
### NOTICE that if a annotation has any letter character it must have an entry in eventID otherwise a cast exception will rise.
def annotToEvent(raw, eventID, default=999999):
    events = []

    sfreq = raw.info['sfreq']  # in Hz
    previousStimValue = 0  # since there is no STIM channel and the events are made based on annotations
    orig_time = 0 if raw.annotations.orig_time is None else raw.annotations.orig_time  # if None set to 0.

    for anot in raw.annotations:
        onsetInSamples = int((anot['onset']) * sfreq + raw.first_samp)  # from seconds to sample
        try:
            eventDescription = eventID[anot["description"]] if (eventID.get(anot["description"]) is not None) else int(
                round(float(anot["description"])))
        except ValueError:
            eventDescription = default

        events.append([onsetInSamples, previousStimValue, eventDescription])

    return np.array(events)


# Makes annotations with window size w_size, centered on the blink event#
# Parameters
# raw        -> eegRawdata (from mne)
# channels   -> list with eog channels
# w_size     -> window size to generate annotations.
# Return:
# all EOG events in a dict that maps eogChannel -> listOfEvents
def eogEventsToAnnotations(raw, channels=[], w_size=0.5):
    allEogEvents = dict()
    for ch in channels:
        eogEvent = mne.preprocessing.find_eog_events(raw, ch_name=ch)
        allEogEvents[ch] = eogEvent

        n_blinks = len(eogEvent)
        onset = eogEvent[:, 0] / raw.info['sfreq'] - (w_size / 2.0)
        duration = np.repeat(w_size, n_blinks)
        description = ['bad blink'] * n_blinks
        annot = mne.Annotations(onset, duration, description,
                                orig_time=raw.info['meas_date'])

        annot += raw.annotations
        raw.set_annotations(annot)

    return allEogEvents
