##Parameters:
# Missing parameters will be handled by Experiment.genericExperiment
# All channels will be used (except reference), since the naming of the channels may vary from database to database. #TODO ? fazer uma mascara para os nomes dos canais? Adaptar GenericExperiments de acordo.
# ID is an identifier (string) for the experiment.
# preprocessParams (dict())
# "srate"            = sampling rate (default:None will use the database)
# "minFreq"          = highpass frequency (default: None, will use the database highpass)
# "maxFreq"          = lowpass frequency (default: None, will use the database lowpass -1)
# "refCh"            = reference to be used (default: None, no rereferencing)
# "cleanByEOG"       = If should use EOG for signal cleaning, after ICA if cleanByEOGICA=True. (default None, will clean using EOG)
# "cleanByEOGICA"    = If should use ICA to filter out EOG artifacts (default None, will not clean using ICA)

# epochsParams (dict())
# tminDelay               = Time (seconds) after the desired events to start the epoch. Affects the calculation of tmin, see mne.Epochs(tmin=) (default, 0.0)
# tmaxDelay               = Time (seconds) after the desired events to finish the epoch. Affects the calculation of tmin, see mne.Epochs(tmax=)(default, 0.0)
# baseline                = Start and finish of the interval used for baseline correction. Defaulf (0, None), i.e. uses the entire epoch, used only if correction == 'mean'.
# correction              = Rescale done by the baseline correction, ‘mean’ | ‘ratio’ | ‘percent’ | ‘zscore’. Default = 'mean'. (if other than mean uses the entire epoch as baseline)

# welchParams (dict())
# "n_fft"            = Number of samples to be used in FFT (default None, 1 second)
# "n_per_seg"        = Number of samples per segment (default None, 1 second)
# "n_overlap"        = Number of overlaping samples  (default None, 50% of n_fft)

# features (list()) of tuples (name(str), params(dict()) with all desired features to be extracted.
# it is not possible to change the parameters and run many of the same feature, e.g. [(bandPower, {"alpha":[7,12],"beta":[12,30]}),(bandPower, {"alpha":[8,13]})] is unavailable, only the last will be saved.
# Default parameters will be used if params is missing.
# e.g. (bandPower, {"alpha":[7,12],"beta":[12,30]})
# name
# SASI               = Spectral Asymmetry implemented in features.SASI (no parameters needed)
# bandPowers         = BandPower implemented in features.bandPowers (bandwidths may be changed)
# alphaAsymmetry     = AlphaAsymmetry implemented in features.alphaAsymmetry (channels and alpha bandwidth may be changed)
class ExperimentParameters(object):
    def __init__(self, ID, preprocessParams={"srate": None, "minFreq": None, "maxFreq": None, "refChannel": None,
                                             "cleanByEOG": None, "cleanByEOGICA":None},
                            epochsParams={"tminDelay": 0.0, "tmaxDelay": 0.0, "baseline":(0, None),'correction':'mean'},
                            welchParams={"n_fft": None, "n_per_seg": None, "n_overlap": None},
                            features=[("SASI", dict()), ("bandPowers", dict()), ('alphaAsymmetry',dict())]):
        self.ID = ID

        self.preprocessParams = dict()
        for param in ["srate", "minFreq", "maxFreq", "refChannel", "cleanByEOG","cleanByEOGICA"]:
            self.preprocessParams[param] = preprocessParams.get(param, None)

        self.epochsParams = dict()
        self.epochsParams["tminDelay"] = epochsParams.get("tminDelay", 0.0)
        self.epochsParams["tmaxDelay"] = epochsParams.get("tmaxDelay", 0.0)
        self.epochsParams["baseline"] = epochsParams.get("baseline", (0,None))
        self.epochsParams["correction"] = epochsParams.get("correction", 'mean')

        self.welchParams = dict()
        for param in ["n_fft", "n_per_seg", "n_overlap"]:
            self.welchParams[param] = welchParams.get(param, None)

        self.features = features

class Experiment(object):

    def __init__(self):
        self.results = None
        self.firstColumns = ["Subject", "Setup"]  # More a reminder than an attribute

    #same as staticPreprocess, maintained to avoid bugs.
    def preprocess(self, db, subID, minFreq, maxFreq, refCh, cleanByEOG=True, cleanByEOGICA=False, notch=True):
        import auxScripts
        from mne.preprocessing.ica import ICA

        subEEG = db.read(subID, notch)

        if refCh is not None:
            subEEG.set_eeg_reference(ref_channels=refCh, projection=False, verbose=None)  # changing reference
            if refCh is not 'average':
                subEEG.info['bads'].append(refCh)  # set the reference as bad channel since its flat after reref, otherwise ICA zeroes all values.

        if type(refCh) == list():
            [subEEG.info['bads'].append(ch) for ch in refCh]  # set ref channels as bad channels since they are flat after reref, otherwise ICA zeroes all values.

        if cleanByEOGICA:
            ica = ICA(max_iter=200, random_state=19) #random state is fixed for better replicability.
            firstSample, lastSample = db.get_boundarySamples(subEEG)
            ica.fit(subEEG.filter(1.0,None),start=firstSample, stop=lastSample) #ICA suffers for frequencies smaller than 1 Hz
            badEOGsources = set()
            for eog in db.eog:
                sources, _ = ica.find_bads_eog(subEEG, eog) #previous blink/bad annotations will be used for rejection
                badEOGsources.update(sources)

            badEOGsources = list(badEOGsources)

            #applying ICA to remove bad sources from final signal
            subEEG = ica.apply(subEEG, exclude=badEOGsources)

        # If any high amplitude blink still exists rejection annotations may be made.
        if cleanByEOG:
            auxScripts.eogEventsToAnnotations(subEEG, db.eog)

        if minFreq != db.highpass and maxFreq != db.lowpass:
            subEEG.filter(minFreq, maxFreq)
        elif (minFreq == db.highpass) and (maxFreq is not None):  # avoids reapplying a highpass filter
            subEEG.filter(None, maxFreq)
        elif (maxFreq == db.lowpass) and (minFreq is not None):
            subEEG.filter(minFreq, None)  # avoids reapplying a lowpass filter

        return subEEG

    @staticmethod
    def staticPreprocess(db, subID, srate, minFreq=None, maxFreq=None, refCh=None, cleanByEOG=True, cleanByEOGICA=False, notch=True):
        import auxScripts
        from mne.preprocessing.ica import ICA

        subEEG = db.read(subID, notch=notch)

        if refCh is not None:
            subEEG.set_eeg_reference(ref_channels=refCh, projection=False, verbose=None)  # changing reference
            if refCh is not 'average':
                subEEG.info['bads'].append(refCh)  # set the reference as bad channel since its flat after reref, otherwise ICA zeroes all values.

        if cleanByEOGICA:
            ica = ICA(max_iter=200, random_state=19) #random state is fixed for better replicability.
            firstSample, lastSample = db.get_boundarySamples(subEEG)
            ica.fit(subEEG.filter(1.0,None),start=firstSample, stop=lastSample) #ICA suffers for frequencies smaller than 1 Hz
            badEOGsources = set()
            for eog in db.eog:
                sources, _ = ica.find_bads_eog(subEEG, eog) #previous blink/bad annotations will be used for rejection
                badEOGsources.update(sources)

            badEOGsources = list(badEOGsources)

            #applying ICA to remove bad sources from final signal
            subEEG = ica.apply(subEEG, exclude=badEOGsources)

        # If any high amplitude blink still exists rejection annotations may be made.
        if cleanByEOG:
            auxScripts.eogEventsToAnnotations(subEEG, db.eog)

        if minFreq != db.highpass and maxFreq != db.lowpass:
            subEEG.filter(minFreq, maxFreq)
        elif (minFreq == db.highpass) and (maxFreq is not None):  # avoids reapplying a highpass filter
            subEEG.filter(None, maxFreq)
        elif (maxFreq == db.lowpass) and (minFreq is not None):
            subEEG.filter(minFreq, None)  # avoids reapplying a lowpass filter

        return subEEG

    def experiment(self, db):
        pass

    # Experiments using desired parameters, with all subjects and channels.
    # db     = database class
    # task   = tasks (list) to be used, e.g. ["EO2000ms"]
    # experimentParameters = list of ExperimentParameters
    #chaannelsOfInteerest <str list | 'all'> --> list with all channels to be used; or 'all' to use all available channels.
    # RETURNS
    # dictionary that maps experimentID and feature to its results.
    def genericExperiment(self, db, tasks, experimentParameters, channelsOfInterest='all', subList=None):
        from features import alphaAsymmetry
        from features import bandPowers
        from features import correlationDim
        from features import dfa
        from features import disconnected
        from features import higuchiFractalDimension
        from features import inversions
        from features import lowMidHighPercentages
        from features import peakFrequency
        from features import PCTAlphaAsymmetry
        from features import PFTA
        from features import bandRatios
        from features import relativePowers
        from features import relativePowersEXT
        from features import SASI
        from features import swingleRatio

        import pandas as pd
        from defaultBands import defaultBands as dfb

        # auxiliary to list all features that use spectral decomposition.
        psdsFeatures=['alphaAsymmetry','bandPowers','disconnected','inversions','lowMidHigh','PCT','peak','PFTA','ratio','relativeBandPowers','relativeBandPowersEXT','SASI','Swingle']

        results = dict()

        for xp in experimentParameters:
            featureList = [f for f,_ in xp.features]
            print(xp.ID)
            results[xp.ID] = dict()
            # reading parameters and getting default values using db.
            # preprocessing
            srate = xp.preprocessParams["srate"] if xp.preprocessParams["srate"] is not None else db.srate
            minFreq = xp.preprocessParams["minFreq"] if xp.preprocessParams["minFreq"] is not None else db.highpass
            maxFreq = xp.preprocessParams["maxFreq"] if xp.preprocessParams["maxFreq"] is not None else db.lowpass
            refChannel = xp.preprocessParams["refChannel"]  #experiment.preprocess handles if refChannel is None
            cleanByEOG = xp.preprocessParams["cleanByEOG"] if xp.preprocessParams["cleanByEOG"] is not None else True
            cleanByEOGICA = xp.preprocessParams["cleanByEOGICA"] if xp.preprocessParams["cleanByEOGICA"] is not None else False #False for retro compatibility with previous experiments.

            # removing reference from channelsOfInterest.
            if channelsOfInterest == 'all':
                channelsOfInterest = db.ch_names.copy()

            try:
                channelsOfInterest.remove(refChannel)
            except:
                pass

            # epochs
            tminDelay = xp.epochsParams["tminDelay"] if xp.epochsParams["tminDelay"] is not None else 0.0
            tmaxDelay = xp.epochsParams["tmaxDelay"] if xp.epochsParams["tmaxDelay"] is not None else 0.0
            baseline = xp.epochsParams['baseline'] if xp.epochsParams["baseline"] is not None else (0,None)
            correction = xp.epochsParams['correction'] if xp.epochsParams["correction"] is not None else (0,None)


            # welch
            n_fft = xp.welchParams["n_fft"] if xp.welchParams["n_fft"] is not None else db.srate  # one second
            n_per_seg = xp.welchParams["n_per_seg"] if xp.welchParams[
                                                           "n_per_seg"] is not None else db.srate  # one second
            n_overlap = xp.welchParams["n_overlap"] if xp.welchParams["n_overlap"] is not None else round(
                n_fft * 0.5)  # 50% of n_fft (round down)

            count = 0
            if subList is None:
                subList = db.subjectList

            for subID in subList:
                count = count + 1
                print(count,'/',len(subList))
                # preprocessing and reading EEG
                eeg = self.preprocess(db, subID, minFreq, maxFreq, refChannel, cleanByEOG,cleanByEOGICA)

                for t in tasks:
                    try:
                        # Using Welch with Hanning sliding windows
                        if [featureList.__contains__(spectralF) for spectralF in psdsFeatures].__contains__(True): #If any feature uses spectral decomposition, does it.

                            psds, freqs, epochs = db.applyWelchInEpochs(eeg, t, n_fft,
                                                                n_per_seg, n_overlap,
                                                                channelsOfInterest, minFreq, maxFreq, baseline, tminDelay, tmaxDelay, srate, correction)

                        else: #If none of the features uses spectral decomposition, it is skiped
                            # setting the variables psds and freqs to avoid non initialized warnings
                            psds = None
                            freqs = None
                            epochs = db.extractEpochs(eeg, t, tminDelay, tmaxDelay, baseline, srate, correction)

                    except ValueError as error:
                        print("#####ERROR#####    " + subID + "         #####ERROR####")
                        print(error)
                        for feature, params in xp.features:
                            r = pd.Series(index=["Subject", "Task", "Error"])
                            r["Subject"] = subID
                            r["Task"] = t
                            r["Error"] = error
                            results[xp.ID][feature] = results[xp.ID].get(feature, pd.DataFrame()).append(r, ignore_index=True)

                        continue    #skips feature extraction

                    #Features
                    for feature, params in xp.features:
                        print(feature)

                        # Alpha Asymmetry
                        if feature == 'alphaAsymmetry':
                            r = alphaAsymmetry(psds, freqs, channelsOfInterest,
                                               channelPairs=params.get("channelPairs", [('F3', 'F4')]),
                                               freqBand=params.get("alpha", dfb().ALPHA))
                            r["Subject"] = subID
                            r["Task"] = t

                        # BandPowers
                        elif feature == 'bandPowers':
                            r = bandPowers(psds, freqs, channelsOfInterest,
                                           delta=params.get("delta", dfb().DELTA),
                                           theta=params.get("theta", dfb().THETA),
                                           alpha=params.get("alpha", dfb().ALPHA),
                                           beta=params.get("beta", dfb().BETA),
                                           gamma=params.get("gamma", dfb().GAMMA))
                            r["Subject"] = subID
                            r["Task"] = t

                        elif feature == 'CD':
                            r = correlationDim(epochs,channelsOfInterest,
                                               emb_dim=params.get('emb_dim',30),
                                               method=params.get('method','avg'),
                                               rvals=params.get('rvals', None),
                                               fit=params.get('fit','poly'))
                            r["Subject"] = subID
                            r["Task"] = t

                        elif feature == 'DFA':
                            print('--fitEexp=',params.get('fit_exp','fit_exp com problema'))

                            r = dfa(epochs, channelsOfInterest,
                                    method=params.get('method', 'avg'),
                                    nvals=params.get('nvals',None),
                                    overlap=params.get('overlap', True),
                                    order=params.get('order',1),
                                    fit_trend=params.get('fit_trend', 'poly'),
                                    fit_exp=params.get('fit_exp', 'poly'))
                            r["Subject"] = subID
                            r["Task"] = t

                        elif feature == 'disconnected':
                            r = disconnected(psds, freqs, channelsOfInterest,
                                             highBetaBand=params.get('highBetaBand', dfb().HIGH_BETA_N),
                                             T3=params.get('T3','T3'),
                                             T4=params.get('T4','T4'))
                            r["Subject"] = subID
                            r["Task"] = t


                        elif feature == 'HFD':
                            r = higuchiFractalDimension(epochs,channelsOfInterest,
                                               k_max=params.get('k_max',30),
                                               method=params.get('method','avg'))
                            r["Subject"] = subID
                            r["Task"] = t

                        elif feature == 'inversions':
                            r = inversions(psds, freqs, channelsOfInterest,
                                           channelPairs=params.get('channelPairs',None),
                                           freqBand=params.get('freqBand','alpha'))
                            r["Subject"] = subID
                            r["Task"] = t

                        #low mid high percentages as used in neurofeeback
                        elif feature == 'lowMidHigh':
                            r = lowMidHighPercentages(psds, freqs, channelsOfInterest,
                                                      low=params.get('low', dfb().LOW_N),
                                                      mid=params.get('mid', dfb().MID_N),
                                                      high=params.get('high', dfb().HIGH_N))
                            r["Subject"] = subID
                            r["Task"] = t

                        # Alpha Asymmetry PCT
                        elif feature == 'PCT':
                            r = PCTAlphaAsymmetry(psds, freqs, channelsOfInterest,
                                                  channelPair=params.get("channelPair", ('F3', 'F4')),
                                                  freqBand=params.get("alpha", dfb().ALPHA),
                                                  threshold=params.get('threshold', 0.0))
                            r["Subject"] = subID
                            r["Task"] = t

                        # Peak of frequency, accepts many band ranges
                        elif feature == 'peak':
                            r = peakFrequency(psds, freqs, channelsOfInterest,
                                              ranges=params.get("ranges", [dfb().ALPHA,dfb().BETA]))
                            r["Subject"] = subID
                            r["Task"] = t

                        # PFTA (Prefrontal Theta Activity)
                        elif feature == "PFTA":
                            theta = params.get('theta', dfb().THETA)
                            r = PFTA(psds, freqs, channelsOfInterest, theta, db.uppercaseChannels)
                            r["Subject"] = subID
                            r["Task"] = t

                        # Ratios
                        elif feature == "ratio":
                            r = bandRatios(psds, freqs, channelsOfInterest,
                                           bandN=params.get('bandN', dfb().THETA),
                                           bandD=params.get('bandD', dfb().BETA))
                            r["Subject"] = subID
                            r["Task"] = t

                        # Relative BandPowers
                        elif feature == 'relativeBandPowers':
                            r = relativePowers(psds, freqs, channelsOfInterest,
                                               delta=params.get("delta", dfb().DELTA),
                                               theta=params.get("theta", dfb().THETA),
                                               alpha=params.get("alpha", dfb().ALPHA),
                                               beta=params.get("beta", dfb().BETA),
                                               gamma=params.get("gamma", dfb().GAMMA))
                            r["Subject"] = subID
                            r["Task"] = t

                        elif feature == 'relativeBandPowersEXT':
                            r = relativePowersEXT(psds, freqs, channelsOfInterest,
                                                  bands=[dfb().DELTA, dfb().THETA, dfb().ALPHA,dfb().BETA,dfb().GAMMA],
                                                  lowestFreq=params.get('lowestFreq', 0.0),
                                                  highestFreq=params.get('highestFreq', 40))
                            r["Subject"] = subID
                            r["Task"] = t

                        # SASI (Spectral Asymmetry Index)
                        elif feature == 'SASI':
                            r = SASI(psds, freqs, channelsOfInterest, params.get('alpha', dfb().ALPHA))
                            r["Subject"] = subID
                            r["Task"] = t

                        elif feature == "Swingle":
                            r = swingleRatio(psds, freqs, fzChannel=params.get("fzChannel",'FZ'))
                            r["Subject"] = subID
                            r["Task"] = t

                        else:
                            print(feature, " is not implemented in genericExperimenter")
                            r = pd.Series(index=["Subject", "Setup", "error"])
                            r["Subject"] = subID
                            r["Task"] = t
                            r["error"] = feature + " is not implemented in genericExperimenter"

                        results[xp.ID][feature] = results[xp.ID].get(feature,pd.DataFrame()).append(r, ignore_index=True)

        return results

    # saves the last experiment on a .csv (default) or pickle(DataFrame) file for further reading.
    def save(self, dir, filename, pickle=True, csv=True):
        if pickle:
            with open(dir + filename + ".df", "wb") as outPickle:
                import pickle
                pickle.dump(self.results, outPickle)

        if csv:
            self.results.to_csv(dir + filename + ".csv")


class Exp_SASI2009(Experiment):

    def __init__(self):
        # 1024 samples in each window with 50% overlap
        self.welchParams = {"n_fft": 1024, "n_per_seg": 1024, "n_overlap": 512}

    def preprocess(self, db, subID):
        if db.uppercaseChannels:
            subEEG = super(Exp_SASI2009, self).preprocess(db, subID, 0.5, 48, ['CZ'])
        else:
            subEEG = super(Exp_SASI2009, self).preprocess(db, subID, 0.5, 48, ['Cz'])
        return subEEG

    ##Experiments using the same setup as in:
    # Hinrikus, H., Suhhova, A., Bachmann, M., Aadamsoo, K., Võhma, Ü., Lass, J., Tuulik, V., 2009.
    # Electroencephalographic spectral asymmetry index for detection of depression.
    # Med. Biol. Eng. Comput. 47, 1291–1299. https://doi.org/10.1007/s11517-009-0554-9

    ##Short description
    ##Setup
    # Band Pass                                  = 0.5 - 48Hz
    # Sampling Frequency                         = 400Hz
    # Electrode Placement                        = 10-20
    # Channels                                   = FP1, FP2, P5, P4, T3, T4, O1, O2
    # Reference Electrode                        = Cz
    # Artifact correction                        = 2 EOGs (MindBrainBody database has only one)
    ##Subjects
    # Gender  = female
    # Age     = 35 (+- 11) years
    # Subjects with depressive disorder without antidepressant treatment
    # Subjects with nonpsychotic depressive disorder as defined by ICD-10 criteria and determined by 17-item (HAM-D) > 14
    #
    # Expected Findings = Positive SASI for depressed and negative for healthy controls
    def experimentDefault(self, db, tasks):
        if db.uppercaseChannels:
            self.experiment(db, tasks, 400, 0.5, 48, ['CZ'], 1024, 1024, 512,
                            ["FP1", "FP2", "P5", "P4", "T7", "T8", "O1", "O2"], 0.0, 2.0, True)
        else:
            self.experiment(db, tasks, 400, 0.5, 48, ['Cz'], 1024, 1024, 512,
                            ["Fp1", "Fp2", "P5", "P4", "T7", "T8", "O1", "O2"], 0.0, 2.0, True)

    # db             = Database object
    # setupPairs     = list of events/tasks of interest
    # e.g. ["EO500", "EO2000"] #for depressionRest
    def experiment(self, db, tasks, srate, minFreq, maxFreq, refCh, n_fft, n_per_seg, n_overlap, channelsOfInterest,
                   tminDelay=0.0, tmaxDelay=0.0, cleanByEOG=True):
        import auxScripts
        import pandas as pd
        import features
        import numpy as np

        # Cleaning self.lastExperimentData
        self.results = pd.DataFrame()

        count = 0;
        for subID in db.subjectList:
            print(count)
            count += 1

            if minFreq is None:
                minFreq = db.highpass
            if maxFreq is None:
                maxFreq = db.lowpass

            # reading and preprocessing dataset as described in the paper
            subEEG = super(Exp_SASI2009, self).preprocess(db, subID, minFreq, maxFreq, refCh,
                                                          cleanByEOG=cleanByEOG)

            for t in tasks:
                # Using Welch with Hanning sliding windows
                try:
                    psds, freqs = db.applyWelchInEpochs(subEEG, t, n_fft,
                                                        n_per_seg, n_overlap,
                                                        channelsOfInterest, minFreq, maxFreq, tminDelay, tmaxDelay, srate, correction)
                except ValueError as error:
                    SASI_Results = pd.Series(index=["Subject", "Setup"] + channelsOfInterest)
                    SASI_Results["Subject"] = subID
                    SASI_Results["Task"] = t
                    for ch in channelsOfInterest:
                        SASI_Results[ch] = 'ERRO:' + str(error)
                    print("#####ERROR#####    " + subID + "         #####ERROR####")
                    print(error)
                    ##Adds a new line Subject, Setup, SASI_ch1 ... SASI_chn
                    self.results = self.results.append(SASI_Results, ignore_index=True)
                    continue  # skips for the next subject

                # Calculating SASI for the subject and saving to self.lastExperimentData.
                SASI_Results = features.SASI(psds, freqs, channelsOfInterest)
                SASI_Results["Subject"] = subID
                SASI_Results["Task"] = t
                ##Adds a new line Subject, Setup, SASI_ch1 ... SASI_chn
                self.results = self.results.append(SASI_Results, ignore_index=True)

# TODO SASI2017
# TODO SASI2018
