# References
# [1] van der Vinne, N., Vollebregt, M.A., van Putten, M.J.A.M., Arns, M., 2017.
# Frontal alpha asymmetry as a diagnostic marker in depression: Fact or fiction? A meta-analysis.
# NeuroImage Clin. 16, 79–87.
# https://doi.org/10.1016/j.nicl.2017.07.006

# [2] Nusslock, R., Shackman, A.J., Harmon-Jones, E., Alloy, L.B., Coan, J.A., Abramson, L.Y., 2011.
# Cognitive Vulnerability and Frontal Brain Asymmetry: Common Predictors of First Prospective Depressive Episode.
# J. Abnorm. Psychol. 120, 497–503.
# https://doi.org/10.1037/a0022940

# [3] Baehr, E., Peter Rosenfeld, J., Baehr, R., Earnest, C., 1998.
# Comparison of two EEG asymmetry indices in depressed patients vs. normal controls.
# Int. J. Psychophysiol. 31, 89–92.
# https://doi.org/10.1016/S0167-8760(98)00041-5

# [4] Reznik, S. J., Nusslock, R., Pornpattananangkul, N., Abramson, L. Y., Coan, J. A., & Harmon-Jones, E. (2017).
# Laboratory-induced learned helplessness attenuates approach motivation as indexed by posterior versus frontal theta activity.
# Cognitive, Affective and Behavioral Neuroscience, 17(4), 904–916.
# https://doi.org/10.3758/s13415-017-0521-0

# [5] Swingle, P. G. (2015).
# Adding Neurotherapy to Your Practice. Adding Neurotherapy to Your Practice, 103–113.
# https://doi.org/10.1007/978-3-319-15527-2

# [6] Ribas, V. R., Ribas, R. G., Nóbrega, J. de A., da Nóbrega, M. V., Espécie, J. A. de A., Calafange, M. T., Calafange, C. de O. M., & Martins, H. A. de L. (2018).
# Pattern of anxiety, insecurity, fear, panic and/or phobia observed by quantitative electroencephalography (QEEG).
# Dementia e Neuropsychologia, 12(3), 264–271.
# https://doi.org/10.1590/1980-57642018dn12-030007

#DEFAULT BANDS
from defaultBands import defaultBands as dfb

#########
## Spectral analysis
#########


#Calculates Alpha Assymetry using the formula: (ln(ch1) - ln(ch2))/(ln(ch1) + ln(ch2)) as in [1,2]
#[1] states that normalization "Normalizing by dividing F4 − F3 by its sum (F4 + F3) enables researchers to rule out
# inter individual EEG differences like individual EEG power (as a result of skull thickness for instance)."
#[2] is one of many that apply ln() at the channel, probably to reduce calculations of small values.
# Parameters:
# psds               = Power Spectral Density with many epochs, channels and frequencies
# freqs              = Frequencies of the PSD
# channelsOfInterest = List of channels used to extract psds and freq
# channelPairs       = List of, Pair of channels (left, right) to be compared, must match the one used to extract psds and freqs
# freqBand           = Band of interest, by default Alpha Band, for alpha Asymmetry.
# the bandwiches may be changed, the values [a,b] means that start at a and finishes at b, selecting the values frequencies
# closer to the bounds selected, as sampling rate may impossibilitate exact frequencies.
def alphaAsymmetry(psds, freqs, channelsOfInterest, channelPairs=[('F3','F4')],freqBand=dfb().ALPHA):
    import auxScripts
    import pandas as pd
    import numpy as np

    chId = auxScripts.invertList(channelsOfInterest)

    alphaAsymmetry = pd.DataFrame(columns=["Channels","AlphaAsymmetry"])

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs

    min_ = freqBand[0]
    max_ = freqBand[1]
    lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs,min_,max_)

    for chPair in channelPairs:
        left = 0.0
        for f in range(lowIdx,highIdx):
            left += psdsMean[chId[chPair[0]]][f]
        right = 0.0
        for f in range(lowIdx, highIdx):
            right += psdsMean[chId[chPair[1]]][f]

        aa = (np.log(right) - np.log(left)) / (np.log(right) + np.log(left))
        alphaAsymmetry = alphaAsymmetry.append({"Channels":chPair[0]+"-"+chPair[1],"AlphaAsymmetry": aa},ignore_index=True)

    return alphaAsymmetry

#Extracts band powers
# Parameters:
# psds               = Power Spectral Density with many epochs, channels and frequencies
# freqs              = Frequencies of the PSD
# channelsOfinterest = List of channels of interest (list of strings), must match the one used to extract psds and freqs
# the bandwiches may be changed, the values [a,b] means that start at a and finishes at b (not included), selecting the values frequencies
# closer to the bounds selected, as sampling rate may impossibilitate exact frequencies.
def bandPowers(psds, freqs, channelsOfInterest,delta=dfb().DELTA,theta=dfb().THETA,alpha=dfb().ALPHA,beta=dfb().BETA,gamma=dfb().GAMMA):
    import auxScripts
    import pandas as pd
    import numpy as np

    bands = {"Delta": delta, "Theta":theta,"Alpha":alpha,"Beta":beta,"Gamma":gamma}
    chId = auxScripts.invertList(channelsOfInterest)

    bandPowers = pd.DataFrame(columns=["Band","Channel","Power"])

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs

    for band in bands.keys():
        min_ = bands[band][0]
        max_ = bands[band][1]
        lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs,min_,max_)

        for ch in channelsOfInterest:
            power = 0.0
            for f in range(lowIdx,highIdx+1):
                power += psdsMean[chId[ch]][f]
            bandPowers = bandPowers.append({"Band":band,"Channel":ch,"Power": power},ignore_index=True)

    return bandPowers

# Does a band ratio, in the form bandN/bandD (default theta/beta ratio)
# Parameters:
# psds               = Power Spectral Density with many epochs, channels and frequencies
# freqs              = Frequencies of the PSD
# channelsOfInterest = List of channels used to extract psds and freq
# bandD and bandN    = pair float, [a,b], indicating the desired band, [a,b)
def bandRatios(psds, freqs, channelsOfInterest, bandN=dfb().THETA, bandD=dfb().BETA):
    import auxScripts
    import pandas as pd
    import numpy as np

    chId = auxScripts.invertList(channelsOfInterest)

    ratios = pd.DataFrame(columns=["Ratio", "Channel", "Value"])

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs

    #BandN
    min_ = bandN[0]
    max_ = bandN[1]
    lowIdxN, highIdxN = auxScripts.extractFreqOfInterestIndexes(freqs, min_, max_)

    #BandD
    min_ = bandD[0]
    max_ = bandD[1]
    lowIdxD, highIdxD = auxScripts.extractFreqOfInterestIndexes(freqs, min_, max_)


    for ch in channelsOfInterest:
        powerN = 0.0
        for f in range(lowIdxN, highIdxN + 1):
            powerN += psdsMean[chId[ch]][f]

        powerD = 0.0
        for f in range(lowIdxD, highIdxD + 1):
            powerD += psdsMean[chId[ch]][f]

        ratios = ratios.append({"Ratio": str(bandN)+' / '+ str(bandD), "Channel": ch, "Value": powerN/powerD}, ignore_index=True)

    return ratios


## Correlation Dimension, see nolds for aditional parameters
# https://cschoel.github.io/nolds/nolds.html#correlation-dimension
# epochs are the epochs to be used to calculate CD
# method <default: avg>{'avg'|<int>}: 'avg' calculates CD for each epoch and averages, if an int, it will use an specific epoch (the int refers to the index of epochs)
# emb_dim (int) -> embedding dimension(instead of using many different dimensions, use the greater)\
# rvals (iterable of floats) -> values for r (default: None, uses a logarithmic scale)
def correlationDim(epochs, channelsOfInterest, emb_dim, method='avg', rvals=None, fit='poly'):
    import nolds
    import pandas as pd
    import sys

    cd = pd.DataFrame(columns=["Channel", "CD"])

    if type(method) == int:
        index = method
        signal = epochs[index]
        for ch in channelsOfInterest:
            sig = signal.get_data(ch)
            print(ch)
            try:
                calculated_cd = nolds.corr_dim(sig[0][0], emb_dim, rvals=rvals,fit=fit)
                cd = cd.append({"Channel": ch, "CD": calculated_cd}, ignore_index=True)
            except:
                cd = cd.append({"Channel": ch, "CD": sys.exc_info()[0]}, ignore_index=True)

    elif method == 'avg':
        for ch in channelsOfInterest:
            calculated_cd = 0
            for e in range(0, len(epochs)):  # using for e in epochs returns np.array type which is undesirable (as it has no get_data() method.
                sig = epochs[e].get_data(ch)
                try:
                    calculated_cd = nolds.corr_dim(sig[0][0], emb_dim, rvals=rvals, fit=fit)
                except:
                    calculated_cd = 0 ##Mean is unaltered

            meanCD = float(calculated_cd)/float(len(epochs))
            cd = cd.append({"Channel": ch, "CD": meanCD},ignore_index=True)
    else:
        print("selected method for CD:"+method+", is not implemented. Use 'avg' or select a specifc index.")

    return cd

## DFA, see nolds for aditional parameters
# https://cschoel.github.io/nolds/nolds.html#correlation-dimension
# epochs are the epochs to be used to calculate DFA
# method {'avg'|<int>}: 'avg' calulates DFA for each epoch and averages, if an int, it will use an specific epoch (the int refers to the index of epochs)
#default parameters use a linear fit as the papers usually use.
def dfa(epochs, channelsOfInterest, method='avg', nvals=None, overlap=True, order=1, fit_trend='poly', fit_exp='poly'):
    import pandas as pd
    import nolds

    dfa = pd.DataFrame(columns=["Channel", "DFA"])

    if type(method) == int:
        index = method
        signal = epochs[index]
        for ch in channelsOfInterest:
            sig = signal.get_data(ch)
            calculated_dfa = nolds.dfa(sig[0][0], nvals, overlap, order, fit_trend, fit_exp)
            dfa = dfa.append({"Channel": ch, "DFA": calculated_dfa}, ignore_index=True)

    #elif method == 'concat':
    #    signal = epochs.concat()###corrigir sintaxe
    #    for ch in channelsOfInterest:
    #        sig = signal.get_data(ch)
    #        calculated_dfa = nolds.dfa(sig[0], nvals, overlap, order, fit_trend, fit_exp)
    #        dfa = dfa.append({"Channel": ch, "DFA": calculated_dfa}, ignore_index=True)

    elif method == 'avg':
        for ch in channelsOfInterest:
            calculated_dfa = 0
            for e in range(0, len(epochs)):  # using for e in epochs returns np.array type which is undesirable (as it has no get_data() method.
                sig = epochs[e].get_data(ch)
                calculated_dfa = calculated_dfa + nolds.dfa(sig[0][0], nvals, overlap, order, fit_trend, fit_exp)

            meanDFA = float(calculated_dfa)/float(len(epochs))
            dfa = dfa.append({"Channel": ch, "DFA": meanDFA}, ignore_index=True)
    else:
        print("selected method for DFA:"+method+", is not implemented. Use 'avg' or select a specifc index.")

    return dfa

# TODO verify this function
# calculates the disconnected TQ-7 feature. (Temporal HighBeta Asymmetry)
# Negligence T3 = 2*T4
# Abuse      T4 = 2*T3
# That said, this method calculates T4/T3 the ratio similar to the inversions method.
# I.e. the response will be 100% for Abuse (indicating twice the activity at T4) and -100% for Negligence (indicating twice the activity at T3).
# Parameters:
# psds               = Power Spectral Density with many epochs, channels and frequencies
# freqs              = Frequencies of the PSD
# channelsList       = List of channels used to extract psds and freq
# highBetaBand       = Pair<float> in the form (a,b) indicating that the range of the high beta band is [a,b)
# T3 and T4    = name of T3 and T4 channels if there is need to change
def disconnected(psds, freqs, channelsList, highBetaBand=dfb().HIGH_BETA_N, T3='T3', T4='T4'):
    import auxScripts
    import pandas as pd
    import numpy as np

    chId = auxScripts.invertList(channelsList)

    disc = pd.Series(index=['Disconnected (%)'])

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs

    lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, highBetaBand[0], highBetaBand[1])

    left = 0.0
    for f in range(lowIdx, highIdx):
        left += psdsMean[chId[T3][f]]
    right = 0.0
    for f in range(lowIdx, highIdx):
        right += psdsMean[chId[T4][f]]

    if (right / left) >= 1:
        d = (right / left) - 1  # e.g. 1.2  -> 0.2
    else:
        d = (left / right) - 1  # e.g. 0.83 -> -0.2
        d = d*(-1)
    disc = disc.append({'Disconnected (%)': d * 100}, ignore_index=True)

    return disc

## Higuchi Fractal Dimension, (https://github.com/hiroki-kojima/HFDA)
# signal must be an array
# k_max must be selected (default=30)
def higuchiFractalDimension(epochs, channelsOfInterest, k_max=30, method='avg'):
    import pandas as pd
    import hfda

    hfd = pd.DataFrame(columns={"Channel","HFD"})

    if type(method) == int:
        index = method
        signal = epochs[index]
        for ch in channelsOfInterest:
            sig = signal.get_data(ch)
            calculated_hfd = hfda.measure(sig[0][0], k_max)
            hfd = hfd.append({"Channel": ch, "HFD": calculated_hfd},ignore_index=True)
    elif method == 'avg':
        for ch in channelsOfInterest:
            calculated_hfd = 0
            for e in range(0, len(epochs)):  # using for e in epochs returns np.array type which is undesirable (as it has no get_data() method.
                sig = epochs[e].get_data(ch)
                calculated_hfd = hfda.measure(sig[0][0], k_max)

            meanHFD = float(calculated_hfd) / float(len(epochs))
            hfd = hfd.append({"Channel": ch, "HFD": meanHFD}, ignore_index=True)
    else:
        print("selected method for HFD:" + method + ", is not implemented. Use 'avg' or select a specifc index.")

    return hfd

# Calculates the ratio between letf-right electrodes, the response indicates that the right hemisphere is X% greater than the left (opposite direction for negative values)
# Parameters:
# psds               = Power Spectral Density with many epochs, channels and frequencies
# freqs              = Frequencies of the PSD
# channelsOfInterest = List of channels used to extract psds and freq
# channelPairs       = List of, Pair of channels (left, right) to be compared, must match the one used to extract psds and freqs
# freqBand           = 'alpha' (default) | 'beta' | Pair<float> in the form (a,b) meaning the interval [a,b). If 'alpha' or 'beta' the default dfb().ALPHA_N or dfb().MID_BETA_N will be used accordingly.
#    The response must be interpreted this way:
#       positive X ---> right is X% greater than left
#       negative X ---> left is X% greater than right
#       e.g.:
#       10% means that the right activity is 10% greater than the left activity.
#       -5% means that the left activity is 5% greater than the right.
# inversions are calculated as l/r and r/l and the result is presented in such a way to maintain the relation above.
def inversions(psds, freqs, channelsOfInterest, channelPairs, freqBand='alpha'):
    import auxScripts
    import pandas as pd
    import numpy as np

    chId = auxScripts.invertList(channelsOfInterest)

    inversion = pd.DataFrame(columns=["Channel Pair", "Band", "Inversion (%)"])

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs

    if type(freqBand) == str:
        if freqBand.upper() == 'ALPHA':
            min_ = dfb().ALPHA_N[0]
            max_ = dfb().ALPHA_N[1]
        elif freqBand.upper() == 'BETA':
            min_ = dfb().MID_BETA_N[0]
            max_ = dfb().MID_BETA_N[1]
    else:
        min_ = freqBand[0]
        max_ = freqBand[1]

    lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, min_, max_)
    for chPair in channelPairs:
        left = 0.0
        for f in range(lowIdx,highIdx):
            left += psdsMean[chId[chPair[0]]][f]
        right = 0.0
        for f in range(lowIdx, highIdx):
            right += psdsMean[chId[chPair[1]]][f]

        if (right / left) >= 1:
            inv = (right / left) - 1 #e.g. 1.2  -> 0.2
        else:
            inv = (left / right) - 1#e.g. 0.83 -> -0.2
            inv = inv*(-1)
        inversion = inversion.append({"Channel Pair":chPair[0]+"-"+chPair[1],"Band":str(freqBand),"Inversion (%)": inv*100},ignore_index=True)

    return inversion


#Calculates the percentages of 3 great bands, low, mid and high frequencies
# psds               = Power Spectral Density with many epochs, channels and frequencies
# freqs              = Frequencies of the PSD
# channelsOfInterest = List of channels used to extract psds and freq
# low, mid and high  = pair of floats [a,b], indicating the desired range of frequencies, [a,b)
#     the percentages will be calculated using the intterval from the beginning of low top the end of high.
#It is advised that the concatenation of low, mid and high to be continuous, i.e. each part starts at the end of the previous one.
def lowMidHighPercentages(psds, freqs, channelsOfInterest, low=dfb().LOW_N, mid=dfb().MID_N, high=dfb().HIGH_N):
    import auxScripts
    import pandas as pd
    import numpy as np

    bands = [low, mid, high]
    chId = auxScripts.invertList(channelsOfInterest)

    lmdPercents = pd.DataFrame(columns=["Band", "Channel", "Power(%)"])

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs

    # total amplitude considers only the range of the bands passed, i.e. starts at the beggining of low and ends at the highest of high.
    totalAmplitude = pd.Series(index=channelsOfInterest)
    lowf = low[0]
    highf = high[1]
    lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, lowf, highf)
    for ch in channelsOfInterest:
        totalAmplitude[chId[ch]] = np.sum(psdsMean[chId[ch]][lowIdx:highIdx + 1])

    for band in bands:
        min_ = band[0]
        max_ = band[1]
        lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, min_, max_)

        for ch in channelsOfInterest:
            power = np.sum([psdsMean[chId[ch]][f] / totalAmplitude[chId[ch]] for f in range(lowIdx, highIdx + 1)])
            lmdPercents = lmdPercents.append({"Band": band, "Channel": ch, "Power(%)": power * 100},
                                                     ignore_index=True)

    return lmdPercents


# Percentage of epochs in which the alpha asymmetry (calculated as (R-L) / (R+L)) **No ln()**, is above a determined threshold, default:0
# Applied to a single pair of channels. See [3]
def PCTAlphaAsymmetry(psds, freqs, channelsOfInterest, channelPair=('F3','F4'),freqBand=dfb().ALPHA, threshold = 0.0):
    import auxScripts
    import pandas as pd

    chId = auxScripts.invertList(channelsOfInterest)

    AAPCT = pd.DataFrame(columns=["Channels", "AlphaAsymmetry (PCT)"])

    totalEpochs = len(psds)

    aa_count = 0
    for psd in psds: ## psds for each epoch (psd.shape == (1, channels, freqs).
        psd = psd[0] # indexing 0 gets into the array, notice the shape above.
        min_ = freqBand[0]
        max_ = freqBand[1]
        lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, min_, max_)

        left = 0.0
        for f in range(lowIdx, highIdx):
            left += psd[chId[channelPair[0]]][f]
        right = 0.0
        for f in range(lowIdx, highIdx):
            right += psd[chId[channelPair[1]]][f]

        aa = (right - left) / (right + left)
        if aa > threshold:
            aa_count = aa_count +1

    aapct = (aa_count/totalEpochs)*100
    AAPCT = AAPCT.append({"Channels": channelPair[0] + "-" + channelPair[1], "AlphaAsymmetry (PCT)": aapct},
                                                   ignore_index=True)

    return AAPCT

# Gets the peak frequency within a range (default alpha band)
# Parameters:
# psds               = Power Spectral Density with many epochs, channels and frequencies
# freqs              = Frequencies of the PSD
# channelsOfinterest = List of channels of interest (list of strings), must match the one used to extract psds and freqs
# ranges              = List<Tuple<float>> [(a,b) ..], indicating that the desired range is [a,b) (default dfb().ALPHA and dfb().BETA)
def peakFrequency(psds, freqs, channelsOfInterest, ranges=[dfb().ALPHA,dfb().BETA]):
    import numpy as np
    import auxScripts
    import pandas as pd

    peaks = pd.DataFrame(columns=["Channel","Range","Peak"])
    chId = auxScripts.invertList(channelsOfInterest)

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs

    for r in ranges:
        # getting frequencies closer to desired band (the indexes)
        minIdx, maxIdx = auxScripts.extractFreqOfInterestIndexes(freqs, r[0], r[1])

        for ch in channelsOfInterest:
            peakIdx = np.argmax(psdsMean[chId[ch]][minIdx:maxIdx + 1]) + minIdx
            peak = freqs[peakIdx] #the peak frequency is where the psds is maximum for that range.
            peaks = peaks.append({"Channel": ch, "Range": str(r), "Peak": peak}, ignore_index=True)

    return peaks

# channelList, must be the same channels used for psds
# uppercase indicates if the database uses uppercase or lowercase channel typing
# []
#return three different calculations for PFTA
# PFTA = Pz - Fz                            (Absolute)
# PFTA = ln(Pz) - ln(Fz)                    (Absolute(Ln))
# PFTA = PercentOf(Pz) - PercentOf(Fz)      (Relative)
def PFTA(psds, freqs, channelList, theta = dfb().THETA, uppercaseChannels = True):
    import auxScripts
    import numpy as np
    import pandas as pd
    
    results = pd.Series(index=['Relative','Absolute','Absolute(Ln)'])

    if uppercaseChannels:
        pz = 'PZ'
        fz = 'FZ'
    else:
        pz = 'Pz'
        fz = 'Fz'

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs

    chId = dict()
    chId['PZ'] = channelList.index(pz)
    chId['FZ'] = channelList.index(fz)

    lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, theta[0], theta[1])

    absolutePower = dict()
    for ch in ['PZ', 'FZ']:
        power = 0.0
        for f in range(lowIdx, highIdx + 1):
            power += psdsMean[chId[ch]][f]

        absolutePower[ch] = power

    # PFTA = Pz - Fz
    results['Absolute'] = absolutePower['PZ'] - absolutePower['FZ']

    # PFTA = ln(Pz) - ln(Fz)
    results['Absolute(Ln)'] = np.log(absolutePower['PZ']) - np.log(absolutePower['FZ'])

    totalAmplitude = psdsMean.sum()

    relativePower = dict()
    for ch in ['FZ', 'PZ']:
        relativePower[ch] = (absolutePower[ch] / totalAmplitude) * 100

    # PFTA = PercentOf(Pz) - PercentOf(Fz)
    results['Relative'] = relativePower['PZ'] - relativePower['FZ']

    return results

def relativePowers(psds, freqs, channelsOfInterest,delta=dfb().DELTA,theta=dfb().THETA,alpha=dfb().ALPHA,beta=dfb().BETA,gamma=dfb().GAMMA):
    import auxScripts
    import pandas as pd
    import numpy as np

    bands = {"Delta": delta, "Theta": theta, "Alpha": alpha, "Beta": beta, "Gamma": gamma}
    chId = auxScripts.invertList(channelsOfInterest)

    bandPercentages = pd.DataFrame(columns=["Band", "Channel", "Power(%)"])

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs


    # total amplitude considers only the range of the bands passed, i.e. starts at the beggining of delta and ends at the highest of gamma.
    totalAmplitude = pd.Series(index=channelsOfInterest)
    lowf = delta[0]
    highf = gamma[1]
    lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, lowf, highf)
    for ch in channelsOfInterest:
        totalAmplitude[chId[ch]] = np.sum(psdsMean[chId[ch]][lowIdx:highIdx+1])

    for band in bands.keys():
        min_ = bands[band][0]
        max_ = bands[band][1]
        lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, min_, max_)

        for ch in channelsOfInterest:
            power = np.sum([psdsMean[chId[ch]][f] / totalAmplitude[chId[ch]] for f in range(lowIdx, highIdx + 1)])
            bandPercentages = bandPercentages.append({"Band": band, "Channel": ch, "Power(%)": power*100}, ignore_index=True)

    return bandPercentages

# Similar to relativePowers, but accept any set of band intervals as a list of pairs (a,b), indicating the interval [a,b) as usual.
# Parameters:
# psds, freqs as returned by welch method
# channelsOfInterest    = list of channels to be used, must match the psds, freq variables
# bands                 = list(<pairs>), indicating the ranges for the bands, int eh form (a,b) means the interval [a,b)
# lowestFreq            = lowest frequency in Hz to be used when calculating the total amplitude (default=0)
# highestFreq           = highest frequency in Hz to be used when calculating the total amplitude (default=40)
def relativePowersEXT(psds, freqs, channelsOfInterest,bands=[], lowestFreq=0.0, highestFreq=40):
    import auxScripts
    import pandas as pd
    import numpy as np

    chId = auxScripts.invertList(channelsOfInterest)

    bandPercentages = pd.DataFrame(columns=["Band", "Channel", "Power(%)"])

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs


    # total aomplitude considers only the range of the bands passed, i.e. starts at the beggining of delta and ends at the highest of gamma.
    totalAmplitude = pd.Series(index=channelsOfInterest)
    lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, lowestFreq, highestFreq)
    for ch in channelsOfInterest:
        totalAmplitude[chId[ch]] = np.sum(psdsMean[chId[ch]][lowIdx:highIdx+1])

    for min_, max_ in bands:
        lowIdx, highIdx = auxScripts.extractFreqOfInterestIndexes(freqs, min_, max_)

        for ch in channelsOfInterest:
            power = np.sum([psdsMean[chId[ch]][f] / totalAmplitude[chId[ch]] for f in range(lowIdx, highIdx + 1)])
            bandPercentages = bandPercentages.append({"Band": '['+str(min_)+','+str(max_)+')', "Channel": ch, "Power(%)": power*100}, ignore_index=True)

    return bandPercentages

# Extracts SASI for a single subject in all channels of interest.
# Parameters:
# psds               = Power Spectral Density with many epochs, channels and frequencies
# freqs              = Frequencies of the PSD
# channelsOfinterest = List of channels of interest (list of strings), must match the one used to extract psds and freqs
def SASI(psds, freqs, channelsOfInterest, alpha=dfb().ALPHA):
    import numpy as np
    import auxScripts
    import pandas as pd

    SASI = pd.Series(index=channelsOfInterest)
    chId = auxScripts.invertList(channelsOfInterest)

    # Final PSD is by the means of the epochs.
    psdsMean = np.mean((np.array(np.mean(psds, axis=1))), axis=0)  # getting mean of epochs

    # Dettecting Fc
    # When detecting central frequency Fc, use all channels
    psdsMeanAll = psdsMean.mean(axis=0)  # getting mean of channels and epochs.

    # getting frequencies closer to alpha band (the indexes)
    alphaMin, alphaMax = auxScripts.extractFreqOfInterestIndexes(freqs, alpha[0], alpha[1])

    # polyfitting
    #setting the points right before and after the range to 0 for a better curve fitting.
    y = [0]
    y.extend(psdsMeanAll[alphaMin:alphaMax+1])
    y.extend([0])
    #fitting
    poly = np.poly1d(np.polyfit(freqs[alphaMin-1:alphaMax + 2], y, 2))
    polynomDelFreq = poly.deriv()

    #Frequencies of Interest
    Fc = polynomDelFreq.roots[0] # maximum point derivative == 0, I get the first (and only) root
    F1, F2 = auxScripts.extractFreqOfInterestIndexes(freqs, Fc - 6, Fc - 2)
    F3, F4 = auxScripts.extractFreqOfInterestIndexes(freqs, Fc + 2, Fc + 26)

    #Extracting SASI for each channel
    Wh = dict()
    Wl = dict()
    for ch in channelsOfInterest:
        #Wlm , where m is the channel. Means the signal density in the low frequency portion i.e. between F1 and F2
        Wl[ch] = 0.0
        for f in range(F1, F2+1):
            Wl[ch] += psdsMean[chId[ch]][f]

        #Whm , where m is the channel. Means the signal density in the high frequency portion i.e. between F3 and F4
        Wh[ch] = 0.0
        for f in range(F3, F4 + 1):
            Wh[ch] += psdsMean[chId[ch]][f]

        SASI[ch] = ((Wh[ch] - Wl[ch]) / (Wh[ch] + Wl[ch]))

    return SASI

# Do the Swingle Ratio HiBeta/Beta (neurofeedback ranges) [5]
# Parameters:
# psds               = Power Spectral Density with many epochs, channels and frequencies
# freqs              = Frequencies of the PSD
# fzChannel          = name of the FZ channel (str)
def swingleRatio(psds, freqs,fzChannel='FZ'):
    ratio = bandRatios(psds, freqs, channelsOfInterest=[fzChannel], bandN=dfb().HIGH_BETA_N, bandD=dfb().BETA_N)
    return ratio