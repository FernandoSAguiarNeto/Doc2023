### REFERENCES #######
# [1] Leys, C., Ley, C., Klein, O., Bernard, P., & Licata, L. (2013).
# Detecting outliers: Do not use standard deviation around the mean, use absolute deviation around the median.
# Journal of Experimental Social Psychology, 49(4), 764–766.
# https://doi.org/10.1016/j.jesp.2013.03.013


######################

class FeaturesWrapper():

    # features must be passed, it may be either a dict or a str
    # dict -> must be the dictionary of a single experiment
    # str -> a complete path to a pandas dictionary with the experiments
    #
    # experiment is the key of the experiment to be read
    # e.g. FeaturesWrapper('path to .pd', 'HOSS2013')
    # e.g.#2 FeaturesWrapper(dictWithMyFeatures)
    def __init__(self, features, experiment=None):
        import pickle

        if (type(features) == str) and (experiment is not None):
            with open(features, 'rb') as infile:
                self.features = pickle.load(infile)[experiment]
        elif type(features) == dict:
            self.features = features
        else:
            print('Features must be a dict or a string')

        self.subjectList = set(self.features[list(self.features.keys())[0]][
                                   'Subject'])  # gets the index of some feature, as all features should have the same subjects.

        # if empty, no nanRemoval was done. Otherwise is a task -> list which maps a task to a set of removed subjects, also the should be a special key
        # 'RemovedInAnyTask' which have all the subjects removed in every task, it helps if one wants to achieve the same population in all tasks.
        self.nanSubjects = {'RemovedInAnyTask': set()}

        ## Auxiliary stuff
        # Definitions of methods by featureName
        self.featureReader = {
            'disconnected':self.read_disconnected,
            'PFTA':self.read_PFTA,
            'Swingle': self.read_Swingle,
            'peak': self.read_Peak_at,
            'ratio': self.read_ratios_at,
            'lowMidHigh': self.read_SlowMidHigh_at,
            'SASI': self.read_SASI_at,
            'bandPowers': self.read_bandPowers_at,
            'relativeBandPowers': self.read_relativeBandPowers_at,
            'relativeBandPowersEXT': self.read_relativeBandPowersEXT_at,
            'CD': self.read_CD_at,
            'DFA': self.read_DFA_at,
            'HFD': self.read_HFD_at,
            'alphaAsymmetry': self.read_alphaAsymmetry_atPair,
            'inversions': self.read_inversions_atPair,
            'PCT': self.read_PCT_atPair
        }

        # indicates the type of the read method for easy parametrization
        self.methodType = {
            self.read_disconnected: 'Solo',
            self.read_PFTA: 'Solo',
            self.read_Swingle: 'Solo',
            self.read_Peak_at : 'Single Channel',
            self.read_ratios_at : 'Single Channel',
            self.read_SlowMidHigh_at : 'Single Channel',
            self.read_SASI_at : 'Single Channel',
            self.read_bandPowers_at : 'Single Channel',
            self.read_relativeBandPowers_at : 'Single Channel',
            self.read_relativeBandPowersEXT_at : 'Single Channel',
            self.read_CD_at : 'Single Channel',
            self.read_DFA_at : 'Single Channel',
            self.read_HFD_at : 'Single Channel',
            self.read_alphaAsymmetry_atPair: 'Channel Pair',
            self.read_inversions_atPair: 'Channel Pair',
            self.read_PCT_atPair: 'Channel Pair'
        }

    # AUXILIARY METHODS
    @staticmethod
    def basicStats(data, dropna, colname='Value'):
        try:
            import numpy as np
            import pandas as pd
            from scipy import stats
            mean = data.mean(skipna=dropna)
            #mode = data.mode(dropna=dropna)
            std = data.std(skipna=dropna)
            q25 = data.quantile(q=0.25)
            q75 = data.quantile(q=0.75)
            dagS, dagA = stats.normaltest(data.values, axis=None)
            shapS, shapA = stats.shapiro(data.values)
            st = pd.DataFrame([[mean, std, q25, q75, shapA, shapS, dagA, dagS]],
                                 columns=['Mean', 'Std', 'q25%', 'q75%', 'SW(alpha)', 'SW(statistic)', 'DaP(alpha)','DaP(statistic)'], index=[colname])
            if np.isnan(dagA):
                print("dagA is nan",data)
        except:
            print(data)
            st = None

        return st

    # Applies Median Absolute Deviation (MAD) [1] to detect outliers in a data frame.
    # Indexes must hold information (e.g. ID), each column must be an attribute.
    # Parameters:
    ## data         -> pandas Data Frame with the data, the index must hold information (e.g. ID)
    ## b            -> float, value attached to a distribution assumption, default is 1.4826 which assumes a normal distributions.
    ##                  if None, b = 1/Quartil75(data) which may assume different distributions, notice that, q75 may be tampered by outliers in very small samples.
    ## deviation    -> float, multiplier to be applied to MAD to obtain the thresholds, 2 = poorly conservative, 2.5 = conservative (default), 3.0 = very conservative
    # Return:
    # outliersByColumn      -> dictionary mapping column (string) to outliers (list)
    # outliers              -> list containing all indexes that are outside the threshold
    # cleanData             -> same as the input vector, without any of the outliers
    @staticmethod
    def MADoutlierDetection(data, b=1.4826, deviation=2.5):
        import numpy as np

        outliersByColumn = dict()

        median = data.median()
        absolutes = np.abs((data - median))
        MAD = absolutes.median() * b
        low = median - (MAD * deviation)
        high = median + (MAD * deviation)
        cleanData = data.where((data > low) & (data < high)).copy()
        cleanData.dropna(inplace=True)

        outliers = list(set(data.index.values) - set(cleanData.index.values))  # indexes that where removed after cleaning

        for col in data.columns:
            outliersByColumn[col] = list(set(data[col].index.values) - set(cleanData[col].index.values))

        return outliersByColumn, outliers, cleanData

    def MADOutlierDetectionAll(self, task, channelList, channelPairsList, b=1.4826, deviation=2.5):
        import pandas as pd

        outliersByColumn = dict()
        outliers = list()
        cleanData = pd.DataFrame()

        for feature in self.features.keys():
            if self.methodType[self.featureReader[feature]] == 'Solo':
                # Solo features ask only for a task and return its value on that task, i.e. have fixed channels or are independent from them
                data = self.featureReader[feature](task)

                dataIndexed = data.copy()

                outliersByColumn_single, outliers_single, cleanData_single = self.MADoutlierDetection(dataIndexed, b, deviation)
                outliersByColumn.update(outliersByColumn_single)
                outliers.extend(outliers_single)
                outliers = list(set(outliers)) # removes duplicates

                cleanData = pd.concat([cleanData, cleanData_single], axis='index', sort=True, ignore_index=False)

            elif self.methodType[self.featureReader[feature]] == 'Single Channel':
                # Single Channel features ask for a task and a channel of interest and return its value on that task-channel
                for ch in channelList:
                    data = self.featureReader[feature](task, ch)
                    dataIndexed = data.copy()

                    outliersByColumn_single, outliers_single, cleanData_single = self.MADoutlierDetection(dataIndexed,
                                                                                                          b, deviation)
                    outliersByColumn.update(outliersByColumn_single)
                    outliers.extend(outliers_single)
                    outliers = list(set(outliers))  # removes duplicates

                    cleanData = pd.concat([cleanData, cleanData_single], axis='index', sort=True, ignore_index=False)

            elif self.methodType[self.featureReader[feature]] == 'Channel Pair':
                # Channel Pair features ask for a task and a channel-pair of interest and return its value on that task-channelPair
                for chp in channelPairsList:
                    data = self.featureReader[feature](chp, task)
                    if not data.empty:
                        dataIndexed = data.copy()

                        outliersByColumn_single, outliers_single, cleanData_single = self.MADoutlierDetection(
                            dataIndexed, b, deviation)
                        outliersByColumn.update(outliersByColumn_single)
                        outliers.extend(outliers_single)
                        outliers = list(set(outliers))  # removes duplicates

                        cleanData = pd.concat([cleanData, cleanData_single], axis='index', sort=True, ignore_index=False)

        return outliersByColumn, outliers, cleanData

    # NaN Handling
    # Every handler changes self.features and also self.nanSubjects indicating both the method used and the subjects filtered OUT

    # Removes a subject if it had an error while extracting features (given by the column Error)
    # The subject is removed from ALL features in that TASK (this helps to maintain the same population in every feature)
    #verbose prints a message if any task/feature had no error column (which implies no error)
    def remove_nan_subjects(self, task, verbose=False):
        import pandas as pd
        self.nanSubjects[task] = self.nanSubjects.get(task, set()) #makes sure that the key == task exists
        for f in self.features.keys():
            try:
                nanSubs = self.features[f].set_index('Subject')[
                             ((self.features[f].set_index('Subject')['Task']==task) &
                              (~pd.isnull(self.features[f].set_index('Subject')['Error'])))
                                ].index.values #getting a list of all subjects with an error in the task
                self.nanSubjects[task].update(nanSubs)
                self.nanSubjects['RemovedInAnyTask'].update(nanSubs)

                #removing tuples with errors
                removeIdx = []
                for subject in nanSubs:
                    idx = self.features[f][((self.features[f]['Subject'] == subject) & (self.features[f]['Task'] == task))].index.values
                    removeIdx.extend(idx)

                self.features[f].drop(index=removeIdx, inplace=True)
            except KeyError as key:
                if str(key.__str__()) == str(KeyError('Error')):
                    if verbose:
                        print('Task ', task, 'has no Error column for feature ', f)
                else:
                    raise KeyError(key)

    # returns a features dictionary which is the concatenation of all features in featuresList
    # the experiments and available features will follow the first featureDict on the list.
    @staticmethod
    def concatenateFeatures(featuresList):
        import pandas as pd
        cFeatures = dict()

        for expName in featuresList[0].keys():
            cFeatures[expName] = cFeatures.get(expName, dict())
            for featureType in featuresList[0][expName].keys():
                cFeatures[expName][featureType] = cFeatures[expName].get(featureType, dict())
                cFeatures[expName][featureType] = pd.concat([f[expName][featureType] for f in featuresList], axis=0,
                                                            sort=False, ignore_index=True)

        return cFeatures

    #####
    # Statitics Methods
    # Methods for statistic data
    # statistics include:
    # mean
    # mode # (unimplemented)
    # standard deviation
    # quantile 25%
    # quantile 75%
    # Shapiro-Wilk Normality Test
    # D'agostino and Pearson Normality Test
    #####

    # extracts statistics from every feature present, channel based features (e.g. alpha peak or band power) will be averaged
    def statisticsHead(self, task):
        # TODO Use multivariate tests for normality
        pass

    #TODO filter by hemisphere

    def featureStatisticsByChannel(self, task, feature, channelList, channelPairsList, dropna=True, statistics=None):
        import pandas as pd

        if statistics is None:
            statistics = pd.DataFrame(columns=['Mean', 'Std', 'q25%', 'q75%', 'SW(alpha)', 'SW(statistic)', 'DaP(alpha)', 'DaP(statistic)'])

        if self.methodType[self.featureReader[feature]] == 'Solo':
            # Solo features ask only for a task and return its value on that task, i.e. have fixed channels or are independent from them
            data = self.featureReader[feature](task)
            for col in data.columns:
                stats = self.basicStats(data[col], dropna, colname=col)
                statistics = pd.concat([statistics, stats], axis='index', sort=True, ignore_index=False)

        elif self.methodType[self.featureReader[feature]] == 'Single Channel':
            # Single Channel features ask for a task and a channel of interest and return its value on that task-channel
            for ch in channelList:
                data = self.featureReader[feature](task, ch)
                for col in data.columns:
                    stats = self.basicStats(data[col], dropna, colname=col)
                    statistics = pd.concat([statistics, stats], axis='index', sort=True, ignore_index=False)

        elif self.methodType[self.featureReader[feature]] == 'Channel Pair':
            # Channel Pair features ask for a task and a channel-pair of interest and return its value on that task-channelPair
            for chp in channelPairsList:
                data = self.featureReader[feature](chp, task)
                if not data.empty:
                    for col in data.columns:
                        stats = self.basicStats(data[col], dropna, colname=col)
                        statistics = pd.concat([statistics, stats], axis='index', sort=True, ignore_index=False)

        return statistics


    # extracts statistics for each channel
    # each line of the pd.DataFrame returned is the value of a (named) feature at its channel (pair)
    def statisticsByChannel(self, task, channelList, channelPairsList, dropna=True):
        # iterates all features present on the experiment FeatureWrapper
        statistics = None
        for f in self.features.keys():
            statistics = self.featureStatisticsByChannel(task, f, channelList, channelPairsList, dropna, statistics)

        return statistics


    # extracts statistics for each channel
    # each line of the pd.DataFrame returned is the value of a (named) feature at its channel (pair)
    def statisticsByChannelOLD(self, task, channelList, channelPairsList, dropna=True):
        import pandas as pd
        statistics = pd.DataFrame(columns=['Mean', 'Std', 'q25%', 'q75%', 'SW(alpha)', 'SW(statistic)', 'DaP(alpha)','DaP(statistic)'])

        # iterates all features present on the experiment FeatureWrapper
        for f in self.features.keys():
            # depending on the feature handles it differently
            if self.methodType[self.featureReader[f]] == 'Solo':
                # Solo features ask only for a task and return its value on that task, i.e. have fixed channels or are independent from them
                data = self.featureReader[f](task)
                for col in data.columns:
                    stats = self.basicStats(data[col], dropna, colname=col)
                    statistics = pd.concat([statistics, stats], axis='index', sort=True, ignore_index=False)

            elif self.methodType[self.featureReader[f]] == 'Single Channel':
                # Single Channel features ask for a task and a channel of interest and return its value on that task-channel
                for ch in channelList:
                    data = self.featureReader[f](task, ch)
                    for col in data.columns:
                        stats = self.basicStats(data[col], dropna, colname=col)
                        statistics = pd.concat([statistics, stats], axis='index', sort=True, ignore_index=False)

            elif self.methodType[self.featureReader[f]] == 'Channel Pair':
                # Channel Pair features ask for a task and a channel-pair of interest and return its value on that task-channelPair
                for chp in channelPairsList:
                    data = self.featureReader[f](chp, task)
                    if not data.empty:
                        for col in data.columns:
                            stats = self.basicStats(data[col], dropna, colname=col)
                            statistics = pd.concat([statistics, stats], axis='index', sort=True, ignore_index=False)

        return statistics

    #####
    # Read Methods (all tasks will be returned, and must be filtered later)
    # All methods here read a single column of a feature, i.e. pair feature-channel or "solo"-feature.
    ## e.g. SASIat(channel) which will have many channels
    ## or PFTA() which will be at specific channels
    #
    # These methods always return a series column, with subjectID as index
    #####

    ## Solo Features (read_X() )
    ## Features that do not vary in channel when calculated, e.g. PFTA (always PZ-FZ)
    ## ignoreThis parameter is used to allow readMany method to work well.

    # TODO Disconnected
    ## TODO verify on features
    ## TODO add to featuresWrapper
    def read_disconnected(self, task, ignoreThis=None):
        pass

    def read_PFTA(self, task, ignoreThis=None):
        pfta = self.features['PFTA']  # renaming for readability
        allPFTA = pfta[(pfta['Task'] == task)][['Absolute', 'Absolute(Ln)', 'Relative', 'Subject']].copy().set_index(
            'Subject')
        allPFTA.columns = ['Absolute PFTA', 'Absolute(Ln) PFTA', 'Relative PFTA']
        return allPFTA

    def read_Swingle(self, task, ignoreThis=None):
        swingle = self.features['Swingle']  # renaming or readability
        allSwingle = swingle[(swingle['Task'] == task)][["Value", 'Subject']].copy().set_index('Subject')
        allSwingle.columns = ['Swingle']
        return allSwingle

    ## Single Channel Features (read_X_at() )
    ## Features that are calculated using a single channel

    def read_bandPowers_at(self, task, channel, bandsSelection=['Alpha', 'Beta', 'Delta', 'Theta', 'Gamma']):
        import pandas as pd

        bp = self.features['bandPowers']  # renaming for readability
        allBP = pd.DataFrame()

        for band in bandsSelection:
            singlePower = bp[(bp['Channel'] == channel) &
                             (bp['Band'] == band) &
                             (bp['Task'] == task)][['Power', 'Subject']].copy().set_index('Subject')

            singlePower.columns = [channel + '_' + band + '_Power']
            allBP = pd.concat([allBP, singlePower], axis=1, sort=True)

        return allBP

    def read_CD_at(self, task, channel):
        cd = self.features['CD']  # renaming for readability
        allCD = cd[(cd['Channel'] == channel) & (cd['Task'] == task)][['CD', 'Subject']].copy().set_index(
            'Subject')
        allCD.columns = [channel + '_CD']

        return allCD

    def read_DFA_at(self, task, channel):
        dfa = self.features['DFA']  # renaming for readability
        allDFA = dfa[(dfa['Channel'] == channel) & (dfa['Task'] == task)][['DFA', 'Subject']].copy().set_index(
            'Subject')
        allDFA.columns = [channel + '_DFA']

        return allDFA

    def read_HFD_at(self, task, channel):
        hfd = self.features['HFD']  # renaming for readability
        allHFD = hfd[(hfd['Channel'] == channel) & (hfd['Task'] == task)][['HFD', 'Subject']].copy().set_index(
            'Subject')
        allHFD.columns = [channel + '_HFD']

        return allHFD

    def read_Peak_at(self, task, channel):
        import pandas as pd
        peak = self.features['peak']  # renaming for readability
        peaksAt = pd.DataFrame()
        for r in peak['Range'].unique():
            if type(r) == str:  # strips eventual nan range
                peaksAtBand = peak[((peak['Task'] == task) & (peak['Range'] == r) & (peak['Channel'] == channel))][
                    ['Peak', 'Subject']].copy().set_index('Subject')
                peaksAtBand.columns = [r + '_Peak_' + channel]
                peaksAt = pd.concat([peaksAt, peaksAtBand], axis=1, sort=True)

        return peaksAt

    def read_ratios_at(self, task, channel):
        import pandas as pd
        ratios = self.features['ratio']  # renaming for readability
        ratiosAt = pd.DataFrame()
        for band in ratios['Ratio'].unique():
            if type(band) == str:  # strips eventual nan range
                ratiosAtBand = \
                ratios[((ratios['Task'] == task) & (ratios['Ratio'] == band) & (ratios['Channel'] == channel))][
                    ['Value', 'Subject']].copy().set_index('Subject')
                ratiosAtBand.columns = [band + '_Ratio_' + channel]
                ratiosAt = pd.concat([ratiosAt, ratiosAtBand], axis=1, sort=True)

        return ratiosAt

    def read_relativeBandPowers_at(self, task, channel):
        import pandas as pd

        bp = self.features['relativeBandPowers']  # renaming for readability
        allBP = pd.DataFrame()

        for band in ['Alpha', 'Beta', 'Delta', 'Theta', 'Gamma']:
            singlePower = bp[(bp['Channel'] == channel) &
                             (bp['Band'] == band) &
                             (bp['Task'] == task)][['Power(%)', 'Subject']].copy().set_index('Subject')

            singlePower.columns = [channel + '_' + band + '_Power(%)']
            allBP = pd.concat([allBP, singlePower], axis=1, sort=True)

        return allBP

    def read_relativeBandPowersEXT_at(self, task, channel):
        import pandas as pd

        bp = self.features['relativeBandPowersEXT']  # renaming for readability
        allBP = pd.DataFrame()

        for band in bp['Band'].unique():
            if band != 'nan':
                singlePower = bp[(bp['Channel'] == channel) &
                                 (bp['Band'] == band) &
                                 (bp['Task'] == task)][['Power(%)', 'Subject']].copy().set_index('Subject')

                singlePower.columns = [channel + '_' + band + '_Power(%)']
                allBP = pd.concat([allBP, singlePower], axis=1, sort=True)

        return allBP

    def read_SASI_at(self, task, channel):
        sasi = self.features['SASI']  # renaming for readability
        singleSASI = sasi[(sasi['Task'] == task)][[channel, 'Subject']].copy().set_index('Subject')
        singleSASI.columns = [channel + '_SASI']
        return singleSASI

    def read_SlowMidHigh_at(self, task, channel):
        import pandas as pd
        import numpy as np
        smh = self.features['lowMidHigh']  # renaming for readability
        smh['Band'] = smh['Band'].apply(lambda x: str(x))  # changing Band from list to str for easy coding

        smhAt = pd.DataFrame()

        for band in smh['Band'].unique():
            if band != 'nan':
                smhAtBand = smh[((smh['Task'] == task) & (smh['Band'] == band) & (smh['Channel'] == channel))][
                    ['Power(%)', 'Subject']].copy().set_index('Subject')
                smhAtBand.columns = [str(band) + '_Power(%)_' + channel]
                smhAt = pd.concat([smhAt, smhAtBand], axis=1, sort=True)

        return smhAt

    ## Channel Pair Features (read_X_atPairs() )
    ## Features that use two channels, e.g. FAA

    def read_alphaAsymmetry_atPair(self, channelPair, task):
        faa = self.features['alphaAsymmetry']  # renaming for readability
        chPair = channelPair[0] + "-" + channelPair[1]
        allFAA = faa[(faa['Channels'] == chPair) &
                     (faa['Task'] == task)][['AlphaAsymmetry', 'Subject']].copy().set_index('Subject')

        allFAA.columns = [chPair + '_AlphaAsymmetry']
        return allFAA

    def read_inversions_atPair(self, channelPair, task):
        import pandas as pd
        inv = self.features['inversions']  # renaming for readability
        allInv = pd.DataFrame()
        chPair = channelPair[0] + "-" + channelPair[1]

        for band in inv['Band'].unique():
            if type(band) == str: # strips eventual nan
                bandInv = inv[(inv['Channel Pair'] == chPair) & (inv['Band'] == band) &
                             (inv['Task'] == task)][['Inversion (%)', 'Subject']].copy().set_index('Subject')

                bandInv.columns = [str(chPair) + '_' + str(band) +'_Inversion (%)']
                allInv = pd.concat([allInv, bandInv], axis=1, sort=True)

        return allInv

    def read_PCT_atPair(self, channelPair, task):
        pct = self.features['PCT']  # renaming for readability
        chPair = channelPair[0] + "-" + channelPair[1]
        allPCT = pct[(pct['Channels'] == chPair) &
                     (pct['Task'] == task)][['AlphaAsymmetry (PCT)', 'Subject']].copy().set_index('Subject')

        allPCT.columns = [chPair + '_AlphaAsymmetry (PCT)']
        return allPCT

    # applies many readFeatures functions at various channels
    # DO NOT mix Single Channel and Channel Pair features when using readMany()
    # Also applying this function to Solo Features may yeld repeated columns, as the channel will loop.
    # Parameters:
    ## functions (list of functions) -> list of functions to be applied
    ## channels (list) -> list of channels of interest (will be ignored for features that are applied to specific channels, such as PFTA)
    # Returns:
    # DataFrame with all feature_channel pairs for all subjects, using subjectID as index
    # Call Example:
    ## fw = FeatureWrapper(features)
    ## x= readMany([fw.read_HFD_at, fw.read_CD_at, fw.read_PFTA], ['Pz', 'Cz', 'Fz', 'F3', 'F4'])
    def readMany(self, task, functions, channels):
        import pandas as pd

        df = pd.DataFrame()

        for func in functions:
            for ch in channels:
                results = func(self, task, ch)
                df = pd.concat([df, results], axis=1, sort=True)

        return results
