#TODO Alterar para comportar graphInfo, similar a subjectInfo

# generic class for databases
class Database(object):
    def __init__(self, rootDir, subjectList, subjectInfo, databaseTasks, codes, timeOfTask, srate, highpass, lowpass, ch_names, eog,
                 uppercase):
        self.rootDir = rootDir
        self.firstColumns = ["Subject", "Setup"]
        self.subjectList = subjectList
        self.subjectInfo = subjectInfo
        self.databaseTasks = databaseTasks
        self.eog = eog

        # holds codes for events.
        self.codes = codes
        self.timeOfTask = timeOfTask  #dict task --> time (seconds)

        # defauult settings of the database
        self.srate = srate
        self.highpass = highpass
        self.lowpass = lowpass
        self.ch_names = ch_names
        self.uppercaseChannels = uppercase

    def get_boundarySamples(self, eeg):
        return eeg.first_samp, eeg.last_samp

    def read(self, subID, notch):
        pass

    def extractEpochs(self,eeg, task, event_keys=None, tminDelay=0.0, tmaxDelay=0.0, baseline=(0,None), srate=None, correction='mean'):
        import mne
        import auxScripts
        import numpy as np

        # Making Epochs
        # Using annotations to generate events, the other events are numbered, and dont need to be specified here
        events = auxScripts.annotToEvent(eeg, event_keys)

        if len(events) == 0:
            raise ValueError("no events")

        tmin = 0 + tminDelay
        tmax = self.timeOfTask[task] + tmaxDelay
        # Using events to generate Epochs, bad_blinks are ignored\
        # also, if some events are not found, the others are still used
        event_ids = self.codes[task]

        decim = 1
        if srate is not None:
            decim = np.round(eeg.info['sfreq']/srate)

        if correction != 'mean': #for corrections other than mean the baseline index must be extracted
            baseline = None # will apply baseline correction after

        epochs = mne.Epochs(eeg, events, event_ids, tmin=tmin, tmax=tmax, baseline=baseline,
                            reject_by_annotation=True, preload=True, on_missing='ignore', decim=decim)

        #if correction == 'mean':   #baseline mean is applie by default in mne.Epochs, if baseline is not None
           # epochs.apply_function(lambda x: (x - np.mean(x)))
        if correction == 'ratio':
            epochs.apply_function(lambda x: (x / np.mean(x)))
        elif correction == 'percent':
            epochs.apply_function(lambda x: ((x - np.mean(x) / np.mean(x))) )
        elif correction == 'zscore':
            epochs.apply_function(lambda x: ((x - np.mean(x)) / np.std(x)))

        return epochs

    def applyWelchInEpochs(self, eeg, task, n_fft, n_per_seg, n_overlap, picks, event_keys, minFreq, maxFreq, baseline=(0,None), tminDelay=0.0, tmaxDelay=0.0, srate=None, correction='mean'):
        import mne

        '''
        # Making Epochs
        # Using annotations to generate events, the other events are numbered, and dont need to be specified here
        events = auxScripts.annotToEvent(eeg, event_keys)

        if len(events) == 0:
            raise ValueError("no events")

        tmin = 0 + tminDelay
        tmax = self.timeOfTask[task] + tmaxDelay
        # Using events to generate Epochs, bad_blinks are ignored\
        # also, if some events are not found, the others are still used
        event_ids = self.codes[task]

        epochs = mne.Epochs(eeg, events, event_ids, tmin=tmin, tmax=tmax, baseline=baseline,
                            reject_by_annotation=True, preload=True, on_missing='ignore')
                            '''
        epochs = Database.extractEpochs(self, eeg, task, event_keys, tminDelay, tmaxDelay, baseline, srate, correction)

        if len(epochs) == 0:
            raise ValueError("all epochs rejected")

        psdsEpochs = []
        for i in range(0, len(epochs)):
            # Using Welch with Hanning sliding windows
            psds, freqs = mne.time_frequency.psd_welch(epochs[i], minFreq, maxFreq, picks=picks,
                                                   n_fft=n_fft,
                                                   n_per_seg=n_per_seg,
                                                   n_overlap=n_overlap,
                                                   reject_by_annotation=True)
            psdsEpochs.append(psds)

        return psdsEpochs, freqs, epochs

    def to_string(self):
        len(self.subjectList)
        self.databaseTasks
        self.eog

        # default settings of the database
        self.srate
        self.highpass
        self.lowpass
        self.ch_names

        ret = "Subjects:\t\t"+str(len(self.subjectList))+"\n"+\
              "Tasks:\t\t\t"+str(self.databaseTasks)+"\n"+ \
              "Sampling Rate:\t\t" + str(self.srate) + "Hz\n" + \
              "Bandpass:\t\t" + str(self.highpass) + "~" + str(self.lowpass)+"\n"+\
              "Channels:\t\t"+str(self.ch_names)+"\n"+\
              "EOG channels:\t\t"+str(self.eog)+"\n"

        return ret


# This class will have the many experiments that can be conducted using MindBrainBody Database
# Must have a method to export the extracted info o a csv.
# TODO add longer epochs for EC and EO
class MindBrainBody(Database):

    def __init__(self, rootDir, infoDir, preload=True):
        # Marker coding:
        # S200 - eyes open rest (EO)
        # S210 - eyes closed rest (EC)
        codes = {"S208": 208, "EO": 200, 'EC': 210, 'new_seg': 1000, "bad_blink": 666, 'no_connect': 999,
                 "antiCap_data_on": 1001, "first_stim": 1002, "DEFAULT": 2000}

        timeOfTask = {'EO': 60, 'EC': 60}

        srate = 2500
        highpass = 0.016
        lowpass = 1000
        ch_names = ['Fp1', 'Fp2', 'F7', 'F3', 'Fz', 'F4', 'F8', 'FC5', 'FC1', 'FC2', 'FC6', 'T7', 'C3', 'Cz', 'C4',
                    'T8', 'VEOG', 'CP5', 'CP1', 'CP2', 'CP6', 'AFz', 'P7', 'P3', 'Pz', 'P4', 'P8', 'PO9', 'O1',
                    'Oz', 'O2', 'PO10', 'AF7', 'AF3', 'AF4', 'AF8', 'F5', 'F1', 'F2', 'F6', 'FT7', 'FC3', 'FC4',
                    'FT8', 'C5', 'C1', 'C2', 'C6', 'TP7', 'CP3', 'CPz', 'CP4', 'TP8', 'P5', 'P1', 'P2', 'P6',
                    'PO7', 'PO3', 'POz', 'PO4', 'PO8']

        databaseTasks = ["EO", "EC"]
        eog = ["VEOG"]
        uppercase = False
        self.otherSubjects = ['sub-032356', 'sub-032357','sub-032426', 'sub-032483', 'sub-032484', 'sub-032485', 'sub-032486', 'sub-032487', 'sub-032489','sub-032369'] #these subject files were corrupted and were removed
        # 'sub-032426' has a reduced sampling rate (500Hz) and bandpass (0.0-200Hz)
        # 'sub-032483', 'sub-032484', 'sub-032485', 'sub-032486', 'sub-032487', 'sub-032489' have reduced samplinmg rates (1000Hz)

        subjectList = ['sub-032301', 'sub-032302', 'sub-032303', 'sub-032304', 'sub-032305', 'sub-032306', 'sub-032307',
                       'sub-032308', 'sub-032309', 'sub-032310', 'sub-032311', 'sub-032312', 'sub-032313', 'sub-032314',
                       'sub-032315', 'sub-032316', 'sub-032317', 'sub-032318', 'sub-032319', 'sub-032320', 'sub-032321',
                       'sub-032322', 'sub-032323', 'sub-032324', 'sub-032325', 'sub-032326', 'sub-032327', 'sub-032328',
                       'sub-032329', 'sub-032330', 'sub-032331', 'sub-032332', 'sub-032333', 'sub-032334', 'sub-032336',
                       'sub-032337', 'sub-032338', 'sub-032339', 'sub-032340', 'sub-032341', 'sub-032342', 'sub-032343',
                       'sub-032344', 'sub-032345', 'sub-032346', 'sub-032347', 'sub-032348', 'sub-032349', 'sub-032350',
                       'sub-032351', 'sub-032352', 'sub-032353', 'sub-032354', 'sub-032355',
                       'sub-032358', 'sub-032359', 'sub-032360', 'sub-032361', 'sub-032362', 'sub-032363', 'sub-032364',
                       'sub-032365', 'sub-032366', 'sub-032367', 'sub-032368', 'sub-032370', 'sub-032371',
                       'sub-032372', 'sub-032373', 'sub-032374', 'sub-032375', 'sub-032376', 'sub-032377', 'sub-032378',
                       'sub-032379', 'sub-032380', 'sub-032381', 'sub-032382', 'sub-032383', 'sub-032385', 'sub-032386',
                       'sub-032387', 'sub-032388', 'sub-032389', 'sub-032390', 'sub-032391', 'sub-032392', 'sub-032393',
                       'sub-032394', 'sub-032395', 'sub-032396', 'sub-032397', 'sub-032398', 'sub-032399', 'sub-032400',
                       'sub-032401', 'sub-032402', 'sub-032403', 'sub-032405', 'sub-032406', 'sub-032407', 'sub-032408',
                       'sub-032409', 'sub-032410', 'sub-032411', 'sub-032412', 'sub-032413', 'sub-032414', 'sub-032415',
                       'sub-032416', 'sub-032417', 'sub-032418', 'sub-032420', 'sub-032421', 'sub-032422', 'sub-032423',
                       'sub-032424', 'sub-032425', 'sub-032427', 'sub-032428', 'sub-032429', 'sub-032430',
                       'sub-032431', 'sub-032432', 'sub-032434', 'sub-032435', 'sub-032436', 'sub-032438', 'sub-032439',
                       'sub-032440', 'sub-032441', 'sub-032442', 'sub-032444', 'sub-032446', 'sub-032447', 'sub-032448',
                       'sub-032449', 'sub-032450', 'sub-032451', 'sub-032452', 'sub-032453', 'sub-032454', 'sub-032455',
                       'sub-032456', 'sub-032457', 'sub-032458', 'sub-032459', 'sub-032460', 'sub-032462', 'sub-032463',
                       'sub-032464', 'sub-032465', 'sub-032466', 'sub-032467', 'sub-032468', 'sub-032469', 'sub-032470',
                       'sub-032471', 'sub-032472', 'sub-032473', 'sub-032474', 'sub-032475', 'sub-032476', 'sub-032477',
                       'sub-032478', 'sub-032479', 'sub-032480', 'sub-032481', 'sub-032482',
                       'sub-032490', 'sub-032491', 'sub-032492',
                       'sub-032493', 'sub-032494', 'sub-032495', 'sub-032496', 'sub-032497', 'sub-032498', 'sub-032499',
                       'sub-032501', 'sub-032502', 'sub-032503', 'sub-032504', 'sub-032505', 'sub-032506', 'sub-032507',
                       'sub-032508', 'sub-032509', 'sub-032510', 'sub-032511', 'sub-032512', 'sub-032513', 'sub-032514',
                       'sub-032515', 'sub-032516', 'sub-032517', 'sub-032518', 'sub-032521', 'sub-032522', 'sub-032523',
                       'sub-032524', 'sub-032525', 'sub-032526', 'sub-032528']
        subjectInfo = self.readInfo(rootDir + '/' + infoDir + '/')

        self.preload=preload

        self.baseReference = 'FCz'

        super(MindBrainBody, self).__init__(rootDir, subjectList, subjectInfo, databaseTasks, codes, timeOfTask, srate, highpass,
                                            lowpass, ch_names, eog, uppercase)

    def get_boundarySamples(self, eeg):
        first = [x['onset'] * eeg.info['sfreq'] for x in eeg.annotations if x['description'] == 'Stimulus/S  1'][0] #The first Stimulus/S 1 marks the first sample
        #half of the patients do EO last and the other half do EC last, so we need to check.
        lastEOStart = [x['onset'] * eeg.info['sfreq'] for x in eeg.annotations if x['description'] == 'Stimulus/S200'][-1]
        lastECStart =  [x['onset'] * eeg.info['sfreq'] for x in eeg.annotations if x['description'] == 'Stimulus/S210'][-1]
        lastSegmentStart = max(lastECStart,lastEOStart)
        #The segment ends a minute after the mark, then
        last = lastSegmentStart + (eeg.info['sfreq']*60) #i.e. 60 seconds after lastSegmentStart.
        return first, last

    def readInfo(self, infoDir):
        if infoDir is None:
            return None
        import pandas as pd
        import os
        info = dict()
        for root, path, files in os.walk(infoDir):
            for file in files:
                info[file.split('.csv')[0]] = pd.read_csv(infoDir + file)
        return info

    # given an subject ID, returns the eeg
    def read(self, subID, notch=True):
        import mne
        import numpy as np
        eeg = mne.io.read_raw_brainvision(self.rootDir + subID + ".vhdr", preload=True)

        if notch: #notch filter at 50Hz (and harmonics) to remove powerline
            eeg = eeg.notch_filter(freqs=np.arange(50,self.lowpass+1,50), notch_widths=None, filter_length='auto', phase='zero', method='fir', fir_window='hamming')
        return eeg

    def applyWelchInEpochs(self, eeg, task, n_fft, n_per_seg, n_overlap, picks, minFreq, maxFreq, baseline=(0,0), tminDelay=0.0, tmaxDelay=0.0, srate=None, correction='mean'):
        event_keys = {'Stimulus/S200': self.codes["EO"], 'Stimulus/S210': self.codes["EC"],
                      'Stimulus/S208': self.codes["S208"],
                      'New Segment/': self.codes["new_seg"],
                      "bad blink": self.codes["bad_blink"],
                      'Comment/no USB Connection to actiCAP': self.codes["no_connect"],
                      'Comment/actiCAP Data On': self.codes["antiCap_data_on"],
                      'Stimulus/S  1': self.codes["first_stim"]}

        psds, freqs, epochs = super(MindBrainBody, self).applyWelchInEpochs(eeg, task, n_fft, n_per_seg, n_overlap, picks,
                                                                    event_keys, minFreq, maxFreq, baseline, tminDelay, tmaxDelay, srate, correction)

        return psds, freqs, epochs

    def extractEpochs(self, eeg, task, tminDelay=0.0, tmaxDelay=0.0, baseline=(0, None), srate=None, correction='mean'):
        event_keys = {'Stimulus/S200': self.codes["EO"], 'Stimulus/S210': self.codes["EC"],
                      'Stimulus/S208': self.codes["S208"],
                      'New Segment/': self.codes["new_seg"],
                      "bad blink": self.codes["bad_blink"],
                      'Comment/no USB Connection to actiCAP': self.codes["no_connect"],
                      'Comment/actiCAP Data On': self.codes["antiCap_data_on"],
                      'Stimulus/S  1': self.codes["first_stim"]}

        epochs = super(MindBrainBody, self).extractEpochs(eeg, task, event_keys,tminDelay,tmaxDelay,baseline,srate, correction)
        return epochs

    def to_string(self):
        ret="MIND-BRAIN-BODY DATASET\n10-10 EEG system\n"+\
        super(MindBrainBody, self).to_string()+\
        "\n\nAdditional Info: All healthy subjects, plenty of data available, see files"

        return ret


class DepressionRest(Database):

    def __init__(self, rootDir, infoFilename):

        self.unnavailableParticipants = [544,571,572]

        databaseTasks = ['EO500ms', 'EC500ms', 'EO2000ms', 'EC2000ms','EOMinute','ECMinute']
        codes = {'keyboard0': 20, "bad blink": 21, 'EO500ms': [2, 4, 6], 'EC500ms': [1, 3, 5], 'EO2000ms': [12, 14, 16],
                 'EC2000ms': [11, 13, 15], 'EOMinute': [32,34,36], 'ECMinute':[31,33,35]}

        timeOfTask = {'EO500ms': 0.5, 'EC500ms': 0.5, 'EO2000ms': 2.0,
                 'EC2000ms': 2.0, 'EOMinute': 60.0, 'ECMinute':60.0}
        srate = 500
        highpass = 0
        lowpass = 250
        ch_names = ['FP1', 'FPZ', 'FP2', 'AF3', 'AF4', 'F7', 'F5', 'F3', 'F1', 'FZ', 'F2', 'F4', 'F6', 'F8', 'FT7',
                    'FC5', 'FC3', 'FC1', 'FCZ', 'FC2', 'FC4', 'FC6', 'FT8', 'T7', 'C5', 'C3', 'C1', 'CZ', 'C2', 'C4',
                    'C6', 'T8', 'M1', 'TP7', 'CP5', 'CP3', 'CP1', 'CPZ', 'CP2', 'CP4', 'CP6', 'TP8', 'M2', 'P7', 'P5',
                    'P3', 'P1', 'PZ', 'P2', 'P4', 'P6', 'P8', 'PO7', 'PO5', 'PO3', 'POZ', 'PO4', 'PO6', 'PO8', 'CB1',
                    'O1', 'OZ', 'O2', 'CB2', 'HEOG', 'VEOG']
        eog = ["HEOG", "VEOG"]
        uppercase = True
        subList = [str(i) for i in range(507, 629) if ((i != 544) and (i != 571) and (i != 572))]
        subjectInfo = self.readInfo(rootDir + '/' + infoFilename)
        subjectInfo.set_index('id',inplace=True)
        super(DepressionRest, self).__init__(rootDir, subList, subjectInfo, databaseTasks, codes, timeOfTask, srate, highpass,
                                             lowpass, ch_names, eog, uppercase)


    def get_availableSubjectInfo(self):
        filteredSubInfo = self.subjectInfo.drop(self.unnavailableParticipants, axis=0)
        return filteredSubInfo

    def get_boundarySamples(self, eeg):
        boundaries = [int(x['onset'] * eeg.info['sfreq']) for x in eeg.annotations if x['description'] == '17']
        return boundaries[0], boundaries[1]

    def readInfo(self, infoFilename):
        if infoFilename is None:
            return None
        import pandas as pd
        subjectInfo = pd.read_excel(infoFilename)
        # changing numeric values for their meanings
        changes = {99: 'noSCID_Diagnosis', 1: 'MDD', 2: 'Past MDD', 50: 'noSCID_CriteriaMet'}
        subjectInfo['MDD'] = subjectInfo["MDD"].replace(changes)
        changes = {1: 'Female', 2: 'Male'}
        subjectInfo['sex'] = subjectInfo["sex"].replace(changes)
        return subjectInfo

    def read(self, subID, eog=None, notch=True):
        import mne
        import numpy as np
        if eog is None:
            eog = self.eog

        eeg = mne.io.read_raw_eeglab(self.rootDir + subID + '.set', preload=True, eog='auto')

        #adding 1-minute annotations and adding the exact duration of each annotation.
        onset = eeg.annotations.onset
        duration = eeg.annotations.duration
        description = eeg.annotations.description
        firstAnnotDone = {'11.0': False, '12.0': False, '13.0': False, '14.0': False, '15.0': False, '16.0': False} #auxiliary flag
        import numpy as np
        for i in range(0, len(duration)):
            # other types of events with string descriptions, must be manually ignored as the verifications below will raise a conversion type error.
            try:
                float(description[i])
                # 500ms epochs
                if (float(description[i]) >= 1) and (float(description[i]) <= 6):
                    duration[i] = 0.5  # half second
                # 2000ms epochs
                elif (float(description[i]) >= 11) and (float(description[i]) <= 16):
                    duration[i] = 2  # 2 seconds
                    # if it is the first time this tag is found, generate 1 minute annotations
                    if not firstAnnotDone[str(float(description[i]))]:
                        firstAnnotDone[str(float(description[i]))] = True
                        onset = np.append(onset, onset[i])
                        duration = np.append(duration, 60)
                        description = np.append(description,
                                                str(float(description[i]) + 20))  # 11 --> 31; 12 --> 32, and so on.

            except ValueError:
                pass

            # other epochs need no treatment (17 for start/finish, and the one-minute events we create)

        eeg.set_annotations(annotations=mne.Annotations(onset, duration, description))

        if notch:  # notch filter at 50Hz (and harmonics) to remove powerline
            eeg = eeg.notch_filter(freqs=np.arange(50, self.lowpass, 50), notch_widths=None, filter_length='auto',
                                   phase='zero', method='fir', fir_window='hamming')

        return eeg

    def applyWelchInEpochs(self, eeg, task, n_fft, n_per_seg, n_overlap, picks, minFreq, maxFreq, baseline=(None,0), tminDelay=0, tmaxDelay=0, srate=None, correction='mean'):
        event_keys = {'keyboard0': 20, "bad blink": 21}

        psds, freqs, epochs = super(DepressionRest, self).applyWelchInEpochs(eeg, task, n_fft, n_per_seg, n_overlap, picks,
                                                                event_keys, minFreq, maxFreq, baseline, tminDelay, tmaxDelay, srate, correction)

        return psds, freqs, epochs

    def extractEpochs(self, eeg, task, tminDelay=0.0, tmaxDelay=0.0, baseline=(0, None),srate=None, correction='mean'):
        event_keys = {'keyboard0': 20, "bad blink": 21}

        epochs = super(DepressionRest, self).extractEpochs(eeg, task, event_keys, tminDelay, tmaxDelay, baseline, srate, correction)
        return epochs

    def to_string(self):
        ret = "DEPRESSION-REST DATASET\n10-10 EEG system\n" + \
              super(DepressionRest, self).to_string() + \
              "\n\nAdditional Info:\n" +\
              "Available Subject information:\n"+ \
              "HamD ('Only done for those who did SCID'), Sex, age, BDI, BDI_Anh, BDI_Mel, TAI, also MDD_Note (containing some comorbidities or additional info about the subject\n" + \
              "\nSubject Diagnosis\n" + \
              'noSCID_Diagnosis (all CLT and some depressed):\t'+str(len(self.subjectInfo[self.subjectInfo.MDD == 'noSCID_Diagnosis']))+"\n"+ \
              'noSCID_CriteriaMet:\t\t\t\t' + str(len(self.subjectInfo[self.subjectInfo.MDD == 'noSCID_CriteriaMet'])) + "\n" + \
              'MDD:\t\t\t\t\t\t' + str(len(self.subjectInfo[self.subjectInfo.MDD == 'MDD'])) + "\n" + \
              'Past MDD:\t\t\t\t\t' + str(len(self.subjectInfo[self.subjectInfo.MDD == 'Past MDD'])) + "\n" + \
              '\nUsing BDI:' +\
              '(Past) MDD (BDI >=13*):\t\t'+str(len(self.subjectInfo[self.subjectInfo.BDI >= 13]))+"\n"+\
              'CTL (BDI <8):\t\t\t\t\t'+str(len(self.subjectInfo[self.subjectInfo.BDI < 8]))+"\n"+\
              '\nDATA unnavailable participants:\t\t\t'+str(len(self.unnavailableParticipants))+"*\n" +\
              '\n*BDI==13 as for an Past MDD, every other depressed subject scores at least 14 in BDI' +\
              '\n** Data missing for to participants 571 (noSCID_CriteriaMet) and 572 (MDD). And 544 was an invalid participant.'

        return ret


class MODMA_Pervasive(Database):
    def __init__(self):
        pass

class MODMA128(Database):
    def __init__(self, rootDir, infoFilename):
        srate = 250
        highpass = 0.1
        lowpass = 80

        databaseTasks = ['1 Minute(s)', '2 Minute(s)']
        codes = {'1 Minute(s)': 1, '2 Minute(s)': 2}

        timeOfTask = {'1 Minute(s)': 60.0, '2 Minute(s)': 120.0}


        ch_names = ['F10','AF8','AF4','F2','E5','FCZ','E7','E8','FP2','E10','FZ','E12','FC1','FPZr','FPZ','AFZ','E17','E18','F1','E20','FPZl','FP1','AF3','F3','E25','AF7','F5','FC5','FC3','C1','E31','F9','F7','FT7','E35','C3','CP1','E38','FT8','E40','C5','CP3','E43','T9','T7','TP7','CP5','E48','E49','E50','P5','P3','E53','E54','CPZ','E56','TP9','P7','E59','P1','E61','PZ','E63','P9','PO7','E66','PO3','E68','E69','O1','E71','POZ','E73','E74','OZ','E76','PO4','E78','E79','E80','E81','E82','O2','E84','P2','E86','CP2','E88','E89','PO8','E91','P4','CP4','E94','P10','P8','P6','CP6','E99','E100','E101','TP8','C6','C4','C2','E106','E107','T8','E109','E110','FC4','FC2','E113','T10','E115','FT9','FC6','E118','E119','E120','FT10','F8','F6','F4','E125','E126','E127','E128','CZ']
        self.ch_names10_10 = ['F10','AF8','AF4','F2','FCZ','FP2','FZ','FC1','FPZr','FPZ','AFZ','F1','FPZl','FP1','AF3','F3','AF7','F5','FC5','FC3','C1','F9','F7','FT7','C3','CP1','FT8','C5','CP3','T9','T7','TP7','CP5','P5','P3','CPZ','TP9','P7','P1','PZ','P9','PO7','PO3','O1','POZ','OZ','PO4','O2','P2','CP2','PO8','P4','CP4','P10','P8','P6','CP6','TP8','C6','C4','C2','T8','FC4','FC2','T10','FT9','FC6','FT10','F8','F6','F4','CZ']

        uppercase = True
        subList = ['02010002', '02010004', '02010005', '02010006', '02010008', '02010010', '02010011', '02010012', '02010013', '02010015', '02010016', '02010018', '02010019', '02010021', '02010022', '02010023', '02010024', '02010025', '02010026', '02010028', '02010030', '02010033', '02010034', '02010036', '02020008', '02020010', '02020013', '02020014', '02020015', '02020016', '02020018', '02020019', '02020020', '02020021', '02020022', '02020023', '02020025', '02020026', '02020027', '02020029', '02030002', '02030003', '02030004', '02030005', '02030006', '02030007', '02030009', '02030014', '02030017', '02030018', '02030019', '02030020', '02030021']
        subjectInfo = self.readInfo(rootDir + '/' + infoFilename)
        subjectInfo.set_index('id', inplace=True)
        super(MODMA128, self).__init__(rootDir, subList, subjectInfo, databaseTasks, codes, timeOfTask, srate, highpass,
                                             lowpass, ch_names, ['E25','E8'], uppercase) #uses E14 and E21 as EOG as they are located right above the eyes.

    def readInfo(self, infoFilename):
        if infoFilename is None:
            return None

        import pandas as pd
        subjectInfo = pd.read_excel(infoFilename)
        changes = {'F': 'Female', 'M': 'Male'}
        subjectInfo['gender'] = subjectInfo["gender"].replace(changes)
        return subjectInfo

    #readAs -> 'eeglab' | 'fif'
    def read(self, subID, eog=None, readAs='fif', notch=True):
        import numpy as np
        import mne
        if eog is None:
            eog = self.eog

        if readAs == 'eeglab':
            eeg = mne.io.read_raw_eeglab(self.rootDir + subID + '.set', preload=True, eog=eog)
        elif readAs == 'fif':
            eeg = mne.io.read_raw_fif(self.rootDir + subID + 'raw.fif', preload=True)

            # Using events to generate annotations
            events = mne.read_events(self.rootDir + subID + '-eve.fif')

            duration = []
            description = []
            onset = events[:, 0] / eeg.info['sfreq']
            for ev in events:
                duration.append(ev[2] * 60)  #ev[2] -> duration in seconds
                description.append(str(ev[2]) + ' Minute(s)')

            annotations = mne.Annotations(onset, duration, description)
            eeg.set_annotations(annotations)

        else:
            print('ERROR invalid filetype')

        if notch: #notch filter at 50Hz (and harmonics) to remove powerline
            eeg = eeg.notch_filter(freqs=np.arange(50,self.lowpass,50), notch_widths=None, filter_length='auto', phase='zero', method='fir', fir_window='hamming')

        return eeg


    def applyWelchInEpochs(self, eeg, task, n_fft, n_per_seg, n_overlap, picks, minFreq, maxFreq, baseline=(None, 0), tminDelay=0.0, tmaxDelay=0.0, srate=None, correction='mean'):
        event_keys = {'1 Minute(s)': 1, "2 Minute(s)": 2}

        psds, freqs, epochs = super(MODMA128, self).applyWelchInEpochs(eeg, task, n_fft, n_per_seg,
                                                                             n_overlap, picks,
                                                                             event_keys, minFreq, maxFreq, baseline,
                                                                             tminDelay, tmaxDelay, srate, correction)

        return psds, freqs, epochs

    def extractEpochs(self, eeg, task, tminDelay=0.0, tmaxDelay=0.0, baseline=(0, None),srate=None, correction='mean'):
        event_keys = {'1 Minute(s)': 1, "2 Minute(s)": 2}

        epochs = super(MODMA128, self).extractEpochs(eeg, task, event_keys, tminDelay, tmaxDelay, baseline,srate,correction)
        return epochs

    def to_string(self):
        ret = "MODMA DATASET (Only Eyes-Closed)\n10-10 EEG system\n" + \
              super(MODMA128, self).to_string() + \
              "\n\nAdditional Info:\n" +\
              "Available Subject information:\n"+ \
              "Gender, Age, gender, education（years）, PHQ-9, CTQ-SF, LES, SSRS, GAD-7, PSQI\n" + \
              "\nSubject Diagnosis\n" + \
              'MDD:\t\t\t\t\t\t' + str(len(self.subjectInfo[self.subjectInfo.type == 'MDD'])) + "\n" + \
              'HC:\t\t\t\t\t' + str(len(self.subjectInfo[self.subjectInfo.type == 'HC'])) + "\n"

        return ret